# Fixed analytical definitions

This directory provides convenient top-level copies of the fixed metabolite-linked host-response
programs and comparison signatures used in the manuscript.

The step-specific analysis packages under `scripts/` retain their original copies so that the executed
workflow remains self-contained. The files here are provided as canonical, easy-to-audit definitions.

Important interpretation boundary:
program scores represent transcriptional resemblance to curated metabolite-linked host responses;
they are not direct measurements of metabolite concentration, gut microbial abundance, or microbial
causation in glioblastoma.
