Step 1 — GBM MR microbiota × gutMGene v2.0 audit

Core rules
- Strict network: exact taxonomic match only.
- Expanded network: includes NCBI-verified descendant taxa.
- Ruminococcus gnavus group -> Mediterraneibacter gnavus is a targeted species mapping, not a one-to-one exact group match.
- Generic Eubacterium was not used for Eubacterium nodatum group.
- Ruminococcaceae UCG002 was left unresolved.
- The microbe–metabolite curated file has no increase/decrease field, so signs are not propagated from microbes to host genes.
- gutMGene_v2_Human_gut_microbe_gene.xlsx was identical to gutMGene_v2_Human_microbe_hostgene_curated.xlsx and was not double-counted.

Key counts
- 12 MR seed taxa
- 7 taxa with curated microbe–metabolite edges under expanded mapping
- 40 selected microbe–metabolite edges
- 27 unique metabolites
- 4 metabolites with curated host-gene links
- 92 complete microbe→metabolite→gene path rows
- 37 unique host genes
- 8 strict complete paths / 8 strict-path genes
- 0 exact overlaps with the 19 metabolites in the prior GBM MR paper
