# Derived tables

Machine-readable derived outputs are grouped by analysis step:

- `step1_gutMGene/`: taxonomy harmonisation and curated microbe–metabolite–gene paths.
- `step2_gutMDisorder/`: human disease-context evidence and integration summaries.
- `step3_bulk/`: bulk program scores, context correlations, survival models and replication summaries.
- `step4_singlecell/`: single-cell pseudobulk scores, localisation tests and state correlations.
- `step4B_robustness/`: leave-one-gene-out and depletion robustness outputs.
- `step5_spatial/`: spatial program scores, same-spot/neighbourhood statistics and targeted niche analyses.
- `step6_specificity/`: matched-random and permutation specificity analyses and cross-modal summaries.

These are derived analytical outputs. Raw TCGA, GEO, gutMGene and gutMDisorder source data are
not redistributed here.
