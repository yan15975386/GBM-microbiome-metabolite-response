# Supplementary material note

The journal-facing supplementary figures and tables are maintained in the separate
`BJC_Supplementary_Information.docx` submission file and are not duplicated here.

This repository contains the reproducibility resources underlying those analyses:
scripts, fixed definitions, audit files, session information, and machine-readable
derived results.
