# Source and quality-control audit files

This directory gathers key input-structure, gene-coverage, reproduction, and source-file audits from
the step-specific analyses. Original copies remain within the corresponding `derived_tables/step*/`
directories.
