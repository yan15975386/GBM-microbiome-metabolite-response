# Software environment information

Session information was available in the archived Step 4 and Step 4B outputs and is copied here for
convenient inspection. Step-specific scripts and configuration files under `scripts/` document the
remaining computational workflow.

The single-cell analyses were run in R 4.4.1 on Linux.
