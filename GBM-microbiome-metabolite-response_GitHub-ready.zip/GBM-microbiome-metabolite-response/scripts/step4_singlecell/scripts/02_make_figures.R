suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
})
`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L || all(is.na(x))) y else x
script_arg <- commandArgs(trailingOnly = FALSE)
script_file <- sub("^--file=", "", script_arg[grepl("^--file=", script_arg)])
script_dir <- if (length(script_file)) dirname(normalizePath(script_file[1])) else file.path(getwd(), "scripts")
source(file.path(script_dir, "00_config.R"))

save_plot <- function(p, stem, w=9, h=6) {
  ggsave(file.path(FIGURE_DIR,paste0(stem,".pdf")),p,width=w,height=h,device=if(capabilities("cairo")) cairo_pdf else pdf)
  ggsave(file.path(FIGURE_DIR,paste0(stem,".png")),p,width=w,height=h,dpi=300)
}
program_label <- c(IPA_response="IPA",Succinate_response="Succinate",TMAO_response="TMAO",Propionate_response="Propionate")

scores <- fread(file.path(TABLE_DIR,"04D_patient_celltype_program_scores.tsv"))
scores <- scores[score_version=="host_causal_core"]
scores[, program_display := factor(program_label[program], levels=c("IPA","Succinate","TMAO","Propionate"))]
ord <- scores[,.(med=median(program_score,na.rm=TRUE)),by=broad_cell_type][order(med),broad_cell_type]
scores[, broad_cell_type := factor(broad_cell_type,levels=ord)]
pA <- ggplot(scores,aes(x=broad_cell_type,y=program_score)) + geom_boxplot(outlier.shape=NA,width=.65) + geom_jitter(width=.12,height=0,size=.7,alpha=.45) + facet_wrap(~program_display,scales="free_y",ncol=2) + coord_flip() + labs(x=NULL,y="Patient-level pseudobulk response score",title="GSE182109 broad-compartment localization",subtitle="Each point is one eligible patient × cell-type pseudobulk; no cell-level P values") + theme_bw(base_size=10)
save_plot(pA,"Figure4A_broad_compartment_localization",10,8)

contr <- fread(file.path(TABLE_DIR,"04F_patient_paired_localization_contrasts.tsv"))
contr <- contr[score_version=="host_causal_core"]
contr[, program_display := factor(program_label[program],levels=c("IPA","Succinate","TMAO","Propionate"))]
pB <- ggplot(contr,aes(x=contrast,y=median_paired_difference)) + geom_hline(yintercept=0,linetype=2) + geom_point(aes(size=paired_patients)) + facet_wrap(~program_display,ncol=2) + coord_flip() + labs(x=NULL,y="Median paired score difference",title="Patient-paired cellular localization contrasts",subtitle="Positive values favor the numerator compartment") + theme_bw(base_size=10)
save_plot(pB,"Figure4B_patient_paired_localization",9,7)

plot_heat <- function(file, title, stem) {
  d <- fread(file); d <- d[score_version=="host_causal_core"]
  if (!nrow(d)) return(invisible(NULL))
  d[, program_display := factor(program_label[program],levels=c("IPA","Succinate","TMAO","Propionate"))]
  p <- ggplot(d,aes(x=signature,y=program_display,fill=rho)) + geom_tile() + geom_text(aes(label=ifelse(is.na(rho),"NA",sprintf("%.2f",rho))),size=3) + scale_fill_gradient2(midpoint=0,limits=c(-1,1),na.value="grey90") + labs(x=NULL,y=NULL,fill="Spearman ρ",title=title,subtitle="Patient-level correlations after removing overlapping genes from the state signature") + theme_bw(base_size=10) + theme(axis.text.x=element_text(angle=45,hjust=1))
  save_plot(p,stem,10,5.5)
}
plot_heat(file.path(TABLE_DIR,"04I_TAM_program_state_correlations_overlap_removed.tsv"),"Metabolite-response programs across TAM states","Figure4C_TAM_state_correlations")
plot_heat(file.path(TABLE_DIR,"04J_tumor_program_Neftel_correlations_overlap_removed.tsv"),"Metabolite-response programs across tumor/glial-like Neftel states","Figure4D_tumor_Neftel_correlations")

gene <- fread(file.path(TABLE_DIR,"04K_program_gene_celltype_pseudobulk_summary.tsv"))
# Limit to the most informative genes already central to the Step 3 biology; this is display-only.
display_genes <- c("CCL2","IL1B","IL6","TNF","NFKB1","MAPK1","MAPK3","CD44","CD163","TGFBR1","JUN","TLR2","TJP1")
gene <- gene[gene %in% display_genes]
pE <- ggplot(gene,aes(x=gene,y=broad_cell_type,size=pmax(median_log2CPM1,0),fill=median_log2CPM1)) + geom_point(shape=21) + labs(x=NULL,y=NULL,size="Median log2CPM",fill="Median log2CPM",title="Host-gene localization across broad GBM compartments",subtitle="Patient-level pseudobulk expression; descriptive") + theme_bw(base_size=10) + theme(axis.text.x=element_text(angle=45,hjust=1))
save_plot(pE,"Figure4E_program_gene_celltype_dotplot",10,6.5)

carry <- fread(file.path(TABLE_DIR,"04L_step4_carry_forward.tsv"))
carry[, program_display := factor(program_label[program],levels=c("IPA","Succinate","TMAO","Propionate"))]
pF <- ggplot(carry,aes(x=program_display,y=TAM_vs_Tumor_median_difference)) + geom_hline(yintercept=0,linetype=2) + geom_point(size=3) + labs(x=NULL,y="TAM − tumor/glial-like paired median difference",title="Single-cell localization summary for spatial carry-forward",subtitle="All four predefined programs proceed to spatial analysis; Step 4 does not reselect programs") + theme_bw(base_size=10)
save_plot(pF,"Figure4F_step4_carry_forward_summary",8,5)

cat(format(Sys.time(),"%Y-%m-%d %H:%M:%S")," Step 4 figures complete:",FIGURE_DIR,"\n")
