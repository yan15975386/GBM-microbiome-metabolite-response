options(stringsAsFactors = FALSE)
set.seed(20260902)

PACKAGE_DIR <- normalizePath(file.path(getwd()), mustWork = TRUE)
if (!dir.exists(file.path(PACKAGE_DIR, "resources"))) {
  # Allows running scripts/09_run_all.R from any working directory.
  cmd <- commandArgs(trailingOnly = FALSE)
  file_arg <- sub("^--file=", "", cmd[grepl("^--file=", cmd)])
  if (length(file_arg) > 0L) {
    PACKAGE_DIR <- normalizePath(file.path(dirname(file_arg[1]), ".."), mustWork = TRUE)
  }
}

OUT_ROOT <- "/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04_singlecell"
TABLE_DIR <- file.path(OUT_ROOT, "tables")
FIGURE_DIR <- file.path(OUT_ROOT, "figures")
LOG_DIR <- file.path(OUT_ROOT, "logs")
dir.create(TABLE_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(FIGURE_DIR, recursive = TRUE, showWarnings = FALSE)
dir.create(LOG_DIR, recursive = TRUE, showWarnings = FALSE)

OBJECT_CANDIDATES <- c(
  "/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_build_from_local_10x/GSE182109_GBM_broad_annotated_lean.rds",
  path.expand("~/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_build_from_local_10x/GSE182109_GBM_broad_annotated_lean.rds")
)
ANNOTATION_CANDIDATES <- c(
  "/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_annotation_fix/02_GSE182109_cell_metadata_marker_reannotated.tsv",
  path.expand("~/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_annotation_fix/02_GSE182109_cell_metadata_marker_reannotated.tsv")
)

PROGRAM_FILE <- file.path(PACKAGE_DIR, "resources", "03A_metabolite_response_programs.tsv")
ANCHOR_FILE <- file.path(PACKAGE_DIR, "resources", "03A_program_upstream_anchors.tsv")
CONTEXT_FILE <- file.path(PACKAGE_DIR, "resources", "03A_bulk_context_signatures.tsv")
TAM_STATE_FILE <- file.path(PACKAGE_DIR, "resources", "04A_TAM_state_signatures.tsv")

MIN_CELLS_PER_PATIENT_CELLTYPE <- 50L
MIN_PATIENTS_PER_CELLTYPE <- 3L
MIN_GENES_PER_SCORE <- 2L
MIN_PATIENTS_FOR_CORRELATION <- 8L

TAM_LABEL_PATTERN <- "^(TAM/myeloid|TAM|Myeloid)$"
TUMOR_LABEL_PATTERN <- "^(Tumor/glial-like|Tumor-like|Tumor|Malignant)$"

# Inferential tests are patient-level only. Cell-level values are descriptive/visualization only.
