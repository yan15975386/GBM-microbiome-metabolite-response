suppressPackageStartupMessages({
  library(data.table)
  library(Matrix)
  library(SeuratObject)
})

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L || all(is.na(x))) y else x
script_arg <- commandArgs(trailingOnly = FALSE)
script_file <- sub("^--file=", "", script_arg[grepl("^--file=", script_arg)])
script_dir <- if (length(script_file)) dirname(normalizePath(script_file[1])) else file.path(getwd(), "scripts")
source(file.path(script_dir, "00_config.R"))

LOG_FILE <- file.path(LOG_DIR, "Step4_singlecell.log")
log_con <- file(LOG_FILE, open = "at")
sink(log_con, type = "output", split = TRUE)
sink(log_con, type = "message", append = TRUE)
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(type = "output"), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

stamp <- function(stage, ...) {
  cat(format(Sys.time(), "%Y-%m-%d %H:%M:%S"), sprintf("%-20s", stage), paste(..., collapse = " "), "\n")
  flush.console()
}
write_tsv <- function(x, name) fwrite(x, file.path(TABLE_DIR, name), sep = "\t", na = "NA")
first_existing <- function(x) {
  y <- x[file.exists(x)]
  if (!length(y)) return(NA_character_)
  normalizePath(y[1], mustWork = TRUE)
}
clean_gene <- function(x) toupper(sub("[.][0-9]+$", "", trimws(as.character(x))))
zsafe <- function(x) {
  s <- stats::sd(x, na.rm = TRUE)
  if (!is.finite(s) || s == 0) return(rep(0, length(x)))
  (x - mean(x, na.rm = TRUE)) / s
}

stamp("START", "Step 4 GSE182109 metabolite-response single-cell localization")
OBJ_PATH <- first_existing(OBJECT_CANDIDATES)
if (is.na(OBJ_PATH)) stop("GSE182109 lean Seurat object not found. Checked: ", paste(OBJECT_CANDIDATES, collapse = " | "))
ANN_PATH <- first_existing(ANNOTATION_CANDIDATES)
stamp("INPUT", "Object:", OBJ_PATH)
stamp("INPUT", "Annotation:", ifelse(is.na(ANN_PATH), "not found; object metadata fallback", ANN_PATH))

obj <- readRDS(OBJ_PATH)
if (!inherits(obj, "Seurat")) stop("Input RDS is not a Seurat object")
if (!"RNA" %in% Assays(obj)) stop("RNA assay is missing")
counts <- tryCatch(SeuratObject::LayerData(obj, assay = "RNA", layer = "counts"), error = function(e) NULL)
if (is.null(counts)) counts <- tryCatch(SeuratObject::GetAssayData(obj, assay = "RNA", slot = "counts"), error = function(e) NULL)
if (is.null(counts)) stop("Could not retrieve RNA raw counts")
if (!inherits(counts, "Matrix")) counts <- as(counts, "dgCMatrix")
meta <- as.data.table(obj[[]], keep.rownames = "cell_id")
if (!identical(meta$cell_id, colnames(counts))) {
  idx <- match(colnames(counts), meta$cell_id)
  if (anyNA(idx)) stop("Object metadata and count matrix cell IDs do not align")
  meta <- meta[idx]
}

# External marker-audited broad labels take precedence if present.
if (!is.na(ANN_PATH)) {
  ann <- fread(ANN_PATH)
  candidate_id_cols <- names(ann)[vapply(ann, function(v) {
    if (!is.character(v)) v <- as.character(v)
    mean(v %in% meta$cell_id) > 0.5
  }, logical(1))]
  if (length(candidate_id_cols)) {
    ann_id <- candidate_id_cols[which.max(vapply(candidate_id_cols, function(k) sum(as.character(ann[[k]]) %in% meta$cell_id), numeric(1)))]
    if ("broad_cell_type_external" %in% names(ann)) {
      map <- setNames(as.character(ann$broad_cell_type_external), as.character(ann[[ann_id]]))
      meta[, broad_cell_type_external := unname(map[cell_id])]
      stamp("ANNOTATION", "Applied broad_cell_type_external from", basename(ANN_PATH), "using ID column", ann_id)
    }
  } else {
    stamp("WARNING", "Could not identify cell-ID column in external annotation; using object metadata")
  }
}

celltype_col <- if ("broad_cell_type_external" %in% names(meta) && sum(!is.na(meta$broad_cell_type_external)) > 0) {
  "broad_cell_type_external"
} else if ("broad_cell_type" %in% names(meta)) {
  "broad_cell_type"
} else stop("No broad cell-type annotation available")
if (!"patient_id" %in% names(meta)) stop("patient_id metadata is required")
meta[, broad_cell_type := as.character(get(celltype_col))]
meta[, patient_id := as.character(patient_id)]
meta <- meta[!is.na(patient_id) & nzchar(patient_id) & !is.na(broad_cell_type) & nzchar(broad_cell_type)]
keep_cells <- meta$cell_id
counts <- counts[, keep_cells, drop = FALSE]
if (!identical(colnames(counts), meta$cell_id)) stop("Internal cell ordering error after metadata filter")

input_audit <- data.table(
  object_path = OBJ_PATH,
  annotation_path = ifelse(is.na(ANN_PATH), NA_character_, ANN_PATH),
  cells = ncol(counts), genes = nrow(counts),
  patients = uniqueN(meta$patient_id),
  broad_cell_types = uniqueN(meta$broad_cell_type),
  celltype_column = celltype_col,
  min_cells_per_patient_celltype = MIN_CELLS_PER_PATIENT_CELLTYPE,
  min_patients_per_celltype = MIN_PATIENTS_PER_CELLTYPE,
  inferential_unit = "patient x broad cell type pseudobulk"
)
write_tsv(input_audit, "04A_singlecell_input_audit.tsv")
write_tsv(meta[, .(cell_id, patient_id, broad_cell_type)], "04A_cell_metadata_analysis_labels.tsv.gz")

programs <- fread(PROGRAM_FILE)
contexts <- fread(CONTEXT_FILE)
tam_states <- fread(TAM_STATE_FILE)
programs[, host_gene := clean_gene(host_gene)]
contexts[, gene := clean_gene(gene)]
tam_states[, gene := clean_gene(gene)]

# Tumor-state signatures are the exact compact Neftel-style programs carried from Step 3.
tumor_states <- contexts[signature %in% c("MES_like", "AC_like", "OPC_like", "NPC_like"), .(signature, gene)]

# Broad contextual signatures are retained only for descriptive overlap audits.
broad_context <- contexts[signature %in% c("TAM", "M2_TAM", "Microglia", "IFN_response", "Hypoxia", "Angiogenesis", "Inflammatory_response", "NFkB_response")]

all_required <- unique(c(programs$host_gene, tam_states$gene, tumor_states$gene, broad_context$gene))
feature_base <- clean_gene(rownames(counts))
feature_dt <- data.table(feature_row = seq_along(feature_base), feature = rownames(counts), gene = feature_base)
map_dt <- feature_dt[gene %in% all_required]
coverage <- data.table(gene = all_required)
coverage[, n_feature_rows := vapply(gene, function(g) sum(feature_base == g), integer(1))]
coverage[, measured := n_feature_rows > 0L]
write_tsv(coverage, "04B_required_gene_coverage.tsv")

extract_selected_counts <- function(gene_list) {
  gene_list <- unique(clean_gene(gene_list))
  out <- Matrix::Matrix(0, nrow = length(gene_list), ncol = ncol(counts), sparse = TRUE,
                        dimnames = list(gene_list, colnames(counts)))
  for (i in seq_along(gene_list)) {
    idx <- which(feature_base == gene_list[i])
    if (length(idx) == 1L) out[i, ] <- counts[idx, ]
    if (length(idx) > 1L) out[i, ] <- Matrix::colSums(counts[idx, , drop = FALSE])
  }
  out
}
sel_counts <- extract_selected_counts(all_required)

# Patient x broad-cell-type pseudobulk. This is the inferential layer.
meta[, group_id := paste(patient_id, broad_cell_type, sep = "|||" )]
group_levels <- unique(meta$group_id)
gidx <- match(meta$group_id, group_levels)
G <- sparseMatrix(i = seq_len(nrow(meta)), j = gidx, x = 1, dims = c(nrow(meta), length(group_levels)),
                  dimnames = list(meta$cell_id, group_levels))
gene_group_counts <- sel_counts %*% G
cell_lib <- Matrix::colSums(counts)
group_lib <- as.numeric(Matrix::crossprod(G, cell_lib))
group_cells <- as.numeric(Matrix::colSums(G))
group_meta <- unique(meta[, .(group_id, patient_id, broad_cell_type)])
group_meta <- group_meta[match(group_levels, group_id)]
group_meta[, cells := as.integer(group_cells)]
group_meta[, library_size := group_lib]

eligible <- group_meta[cells >= MIN_CELLS_PER_PATIENT_CELLTYPE]
eligible_types <- eligible[, .(eligible_patients = uniqueN(patient_id)), by = broad_cell_type][eligible_patients >= MIN_PATIENTS_PER_CELLTYPE, broad_cell_type]
eligible <- eligible[broad_cell_type %in% eligible_types]
if (!nrow(eligible)) stop("No patient x cell-type groups pass the prespecified eligibility thresholds")
eidx <- match(eligible$group_id, group_levels)
PB <- gene_group_counts[, eidx, drop = FALSE]
LIB <- group_lib[eidx]
logcpm <- log2(t(t(as.matrix(PB)) / pmax(LIB, 1)) * 1e6 + 1)
colnames(logcpm) <- eligible$group_id
# Z-standardize each gene across eligible pseudobulk groups, matching Step 3's dataset-level gene standardization.
gene_z <- t(apply(logcpm, 1, zsafe))
rownames(gene_z) <- rownames(logcpm); colnames(gene_z) <- colnames(logcpm)

write_tsv(group_meta, "04C_patient_celltype_group_audit_all.tsv")
write_tsv(eligible, "04C_patient_celltype_groups_eligible.tsv")

score_program_matrix <- function(score_version) {
  rows <- if (score_version == "host_causal_core") programs[score_set == "host_causal_core"] else programs
  res <- list()
  for (prog in unique(rows$program)) {
    d <- rows[program == prog]
    genes <- d$host_gene[d$host_gene %in% rownames(gene_z)]
    if (!length(genes)) next
    signs <- d$sign[match(genes, d$host_gene)]
    vals <- colMeans(sweep(gene_z[genes, , drop = FALSE], 1, signs, `*`), na.rm = TRUE)
    res[[length(res)+1L]] <- data.table(group_id = names(vals), program = prog, score_version = score_version,
                                        program_score = as.numeric(vals), genes_measured = length(genes),
                                        genes_requested = uniqueN(d$host_gene),
                                        coverage = length(genes)/uniqueN(d$host_gene))
  }
  rbindlist(res, fill = TRUE)
}
prog_scores <- rbind(score_program_matrix("host_causal_core"), score_program_matrix("expanded"), fill = TRUE)
prog_scores <- merge(prog_scores, eligible[, .(group_id, patient_id, broad_cell_type, cells, library_size)], by = "group_id", all.x = TRUE)
write_tsv(prog_scores, "04D_patient_celltype_program_scores.tsv")

program_coverage <- prog_scores[, .(genes_measured=max(genes_measured), genes_requested=max(genes_requested), coverage=max(coverage)), by=.(program,score_version)]
write_tsv(program_coverage, "04D_singlecell_program_gene_coverage.tsv")
if (any(program_coverage[score_version=="host_causal_core", genes_measured < MIN_GENES_PER_SCORE])) {
  stop("At least one causal-core program has fewer than ", MIN_GENES_PER_SCORE, " measured genes")
}

# Descriptive cell-type localization across independent patients.
celltype_summary <- prog_scores[, .(
  eligible_patient_groups = .N,
  patients = uniqueN(patient_id),
  median_score = median(program_score, na.rm = TRUE),
  q1 = quantile(program_score, 0.25, na.rm = TRUE),
  q3 = quantile(program_score, 0.75, na.rm = TRUE),
  mean_score = mean(program_score, na.rm = TRUE)
), by = .(program, score_version, broad_cell_type)]
write_tsv(celltype_summary, "04E_broad_celltype_program_summary.tsv")

# Prespecified paired patient-level localization contrasts. No cell-level P values.
canonical_ref <- function(x, pattern) {
  hits <- unique(x[grepl(pattern, x, ignore.case = TRUE)])
  if (!length(hits)) return(NA_character_)
  hits[1]
}
TAM_LABEL <- canonical_ref(eligible$broad_cell_type, TAM_LABEL_PATTERN)
TUMOR_LABEL <- canonical_ref(eligible$broad_cell_type, TUMOR_LABEL_PATTERN)
ENDOTHELIAL_LABEL <- canonical_ref(eligible$broad_cell_type, "^Endothelial$")
PERICYTE_LABEL <- canonical_ref(eligible$broad_cell_type, "^(Pericyte/VSMC|Pericyte)$")
OLIGO_LABEL <- canonical_ref(eligible$broad_cell_type, "^(Oligodendrocyte/OPC|Oligodendrocyte_OPC)$")
contrast_specs <- data.table(
  contrast = c("TAM_vs_Tumor", "Endothelial_vs_Tumor", "Pericyte_vs_Tumor", "OligoOPC_vs_Tumor"),
  numerator = c(TAM_LABEL, ENDOTHELIAL_LABEL, PERICYTE_LABEL, OLIGO_LABEL),
  denominator = rep(TUMOR_LABEL, 4)
)
contrast_specs <- contrast_specs[!is.na(numerator) & !is.na(denominator)]
contrast_results <- list()
for (sv in unique(prog_scores$score_version)) for (pr in unique(prog_scores$program)) {
  d <- prog_scores[score_version == sv & program == pr]
  for (k in seq_len(nrow(contrast_specs))) {
    a <- d[broad_cell_type == contrast_specs$numerator[k], .(patient_id, score_a=program_score)]
    b <- d[broad_cell_type == contrast_specs$denominator[k], .(patient_id, score_b=program_score)]
    m <- merge(a,b,by="patient_id")
    p <- if (nrow(m) >= 3L) suppressWarnings(wilcox.test(m$score_a,m$score_b,paired=TRUE,exact=FALSE)$p.value) else NA_real_
    diff <- m$score_a-m$score_b
    contrast_results[[length(contrast_results)+1L]] <- data.table(program=pr,score_version=sv,contrast=contrast_specs$contrast[k],
      numerator=contrast_specs$numerator[k],denominator=contrast_specs$denominator[k],paired_patients=nrow(m),
      median_paired_difference=if(nrow(m)) median(diff,na.rm=TRUE) else NA_real_,
      mean_paired_difference=if(nrow(m)) mean(diff,na.rm=TRUE) else NA_real_,p_value=p)
  }
}
contrasts <- rbindlist(contrast_results, fill=TRUE)
contrasts[, FDR := p.adjust(p_value, method="BH")]
write_tsv(contrasts, "04F_patient_paired_localization_contrasts.tsv")

# Generic signed signature scoring from pseudobulk gene z-scores.
score_signature_table <- function(sig_dt, compartment_label, analysis_name) {
  if (is.na(compartment_label)) return(list(scores=data.table(), correlations=data.table(), coverage=data.table()))
  groups <- eligible[broad_cell_type == compartment_label, group_id]
  if (!length(groups)) return(list(scores=data.table(), correlations=data.table(), coverage=data.table()))
  cols <- match(groups, colnames(gene_z)); cols <- cols[!is.na(cols)]
  sig_res <- list(); cov_res <- list()
  for (sig in unique(sig_dt$signature)) {
    req <- unique(sig_dt[signature==sig, gene])
    avail <- intersect(req, rownames(gene_z))
    cov_res[[length(cov_res)+1L]] <- data.table(analysis=analysis_name,signature=sig,requested=length(req),measured=length(avail),coverage=length(avail)/length(req),genes=paste(avail,collapse=";"))
    if (length(avail) >= 2L) {
      vals <- colMeans(gene_z[avail, cols, drop=FALSE], na.rm=TRUE)
      sig_res[[length(sig_res)+1L]] <- data.table(group_id=colnames(gene_z)[cols],signature=sig,signature_score=as.numeric(vals))
    }
  }
  scores <- rbindlist(sig_res,fill=TRUE)
  if (nrow(scores)) scores <- merge(scores, eligible[,.(group_id,patient_id,broad_cell_type)], by="group_id", all.x=TRUE)
  list(scores=scores, coverage=rbindlist(cov_res,fill=TRUE))
}

tam_sig <- score_signature_table(tam_states, TAM_LABEL, "TAM_state")
tum_sig <- score_signature_table(tumor_states, TUMOR_LABEL, "Tumor_Neftel_state")
write_tsv(tam_sig$scores, "04G_TAM_patient_signature_scores.tsv")
write_tsv(tam_sig$coverage, "04G_TAM_signature_coverage.tsv")
write_tsv(tum_sig$scores, "04H_tumor_patient_Neftel_scores.tsv")
write_tsv(tum_sig$coverage, "04H_tumor_Neftel_signature_coverage.tsv")

# Overlap-removed program-vs-state correlations at patient level.
correlate_overlap_removed <- function(sig_dt, compartment_label, analysis_name) {
  if (is.na(compartment_label)) return(data.table())
  out <- list()
  dprog <- prog_scores[broad_cell_type == compartment_label]
  for (sv in unique(dprog$score_version)) for (pr in unique(dprog$program)) {
    prow <- if (sv == "host_causal_core") programs[program==pr & score_set=="host_causal_core"] else programs[program==pr]
    pgenes <- unique(prow$host_gene[prow$host_gene %in% rownames(gene_z)])
    for (sig in unique(sig_dt$signature)) {
      sreq <- unique(sig_dt[signature==sig,gene])
      sgenes <- setdiff(intersect(sreq, rownames(gene_z)), pgenes)
      groups <- dprog[score_version==sv & program==pr, group_id]
      groups <- intersect(groups, eligible[broad_cell_type==compartment_label,group_id])
      cols <- match(groups,colnames(gene_z)); ok <- !is.na(cols); groups <- groups[ok]; cols <- cols[ok]
      if (length(sgenes) < 2L || length(groups) < MIN_PATIENTS_FOR_CORRELATION) {
        out[[length(out)+1L]] <- data.table(analysis=analysis_name,compartment=compartment_label,program=pr,score_version=sv,signature=sig,
          n_patients=length(groups),signature_genes_after_overlap_removal=length(sgenes),overlap_removed=paste(intersect(sreq,pgenes),collapse=";"),rho=NA_real_,p_value=NA_real_)
        next
      }
      pdat <- dprog[score_version==sv & program==pr & group_id %in% groups,.(group_id,patient_id,program_score)]
      sval <- colMeans(gene_z[sgenes, cols, drop=FALSE], na.rm=TRUE)
      sdat <- data.table(group_id=groups, signature_score=as.numeric(sval))
      m <- merge(pdat,sdat,by="group_id")
      ct <- suppressWarnings(cor.test(m$program_score,m$signature_score,method="spearman",exact=FALSE))
      out[[length(out)+1L]] <- data.table(analysis=analysis_name,compartment=compartment_label,program=pr,score_version=sv,signature=sig,
        n_patients=nrow(m),signature_genes_after_overlap_removal=length(sgenes),overlap_removed=paste(intersect(sreq,pgenes),collapse=";"),rho=unname(ct$estimate),p_value=ct$p.value)
    }
  }
  z <- rbindlist(out,fill=TRUE)
  z[, FDR := p.adjust(p_value,method="BH")]
  z
}

tam_corr <- correlate_overlap_removed(tam_states,TAM_LABEL,"TAM_state_overlap_removed")
tum_corr <- correlate_overlap_removed(tumor_states,TUMOR_LABEL,"Tumor_Neftel_overlap_removed")
write_tsv(tam_corr,"04I_TAM_program_state_correlations_overlap_removed.tsv")
write_tsv(tum_corr,"04J_tumor_program_Neftel_correlations_overlap_removed.tsv")

# Program-gene pseudobulk expression and detection by broad cell type for interpretation.
prog_genes <- unique(programs$host_gene)
gene_expr_long <- list()
for (g in intersect(prog_genes,rownames(logcpm))) {
  vals <- logcpm[g,,drop=TRUE]
  tmp <- copy(eligible)
  tmp[, gene := g]
  tmp[, log2CPM1 := as.numeric(vals[match(group_id,names(vals))])]
  gene_expr_long[[length(gene_expr_long)+1L]] <- tmp[,.(patient_id,broad_cell_type,cells,gene,log2CPM1)]
}
gene_expr_long <- rbindlist(gene_expr_long,fill=TRUE)
gene_celltype_summary <- gene_expr_long[,.(patients=.N,median_log2CPM1=median(log2CPM1,na.rm=TRUE),q1=quantile(log2CPM1,.25,na.rm=TRUE),q3=quantile(log2CPM1,.75,na.rm=TRUE)),by=.(gene,broad_cell_type)]
write_tsv(gene_celltype_summary,"04K_program_gene_celltype_pseudobulk_summary.tsv")

# Decision table for Step 5 spatial carry-forward: no selection on P value; all four programs remain, with interpretive priority inherited from Step 3.
priority <- data.table(program=c("IPA_response","Succinate_response","TMAO_response","Propionate_response"),
                       step3_priority=c("Primary","Primary","Primary","Secondary"))
loc <- contrasts[score_version=="host_causal_core" & contrast=="TAM_vs_Tumor",.(program,TAM_vs_Tumor_median_difference=median_paired_difference,TAM_vs_Tumor_p=p_value,TAM_vs_Tumor_FDR=FDR,paired_patients)]
priority <- merge(priority,loc,by="program",all.x=TRUE)
priority[, carry_to_spatial := TRUE]
priority[, rule := "All four predefined programs carried forward; Step 4 localizes but does not reselect gene sets/programs"]
write_tsv(priority,"04L_step4_carry_forward.tsv")

manifest <- data.table(
  accession="GSE182109", cells_analyzed=ncol(counts), patients=uniqueN(meta$patient_id),
  eligible_patient_celltype_groups=nrow(eligible), eligible_broad_celltypes=uniqueN(eligible$broad_cell_type),
  TAM_label=TAM_LABEL, tumor_label=TUMOR_LABEL,
  scoring="gene-wise z-score of log2(CPM+1) patient×cell-type pseudobulk; signed mean according to Step3 fixed metabolite-gene direction",
  inference="paired patient-level Wilcoxon and patient-level Spearman only; no cell-level P values",
  overlap_control="program genes removed from TAM/Neftel signatures before within-compartment correlations"
)
write_tsv(manifest,"04M_analysis_manifest.tsv")
capture.output(sessionInfo(), file=file.path(TABLE_DIR,"sessionInfo.txt"))
stamp("COMPLETE", "Step 4 numerical analysis complete. Tables:", TABLE_DIR)
