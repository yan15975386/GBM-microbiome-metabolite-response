# Step 4 — GSE182109 single-cell localization of fixed microbiota–metabolite host-response programs

This package carries the four Step 3 programs into an independent single-cell dataset **without reselecting genes or programs**:

- IPA_response
- Succinate_response
- TMAO_response
- Propionate_response

## Primary input

The script automatically searches for the previously generated lean GSE182109 Seurat object at either:

- `/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_build_from_local_10x/GSE182109_GBM_broad_annotated_lean.rds`
- `~/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_build_from_local_10x/GSE182109_GBM_broad_annotated_lean.rds`

It also uses the marker-audited annotation, when present:

- `/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_annotation_fix/02_GSE182109_cell_metadata_marker_reannotated.tsv`

`broad_cell_type_external` takes precedence over older broad labels.

## Prespecified statistical rules

- Inferential unit: **patient × broad cell-type pseudobulk**.
- Minimum 50 cells per patient × cell-type group.
- A broad cell type must be represented by at least 3 eligible patients.
- **No cell-level P values.**
- Program genes are fixed from Step 3.
- Main score is `host_causal_core`; expanded score is sensitivity analysis.
- Within TAM and tumor/glial-like compartments, genes overlapping the response program are removed from the comparator state signature before correlation.
- All four programs proceed to Step 5 spatial analysis regardless of Step 4 P values; Step 4 is localization, not a new discovery filter.

## Main analyses

1. Broad cell-compartment localization across patient-level pseudobulks.
2. Prespecified paired contrasts, especially TAM/myeloid vs Tumor/glial-like.
3. TAM-state analysis: microglial, monocyte-inflammatory, IFN, immunoregulatory, SPP1/LAM, pro-inflammatory and cycling programs.
4. Tumor/glial-like analysis using the same compact MES/AC/OPC/NPC programs used in Step 3.
5. Overlap-removed patient-level correlations to limit mathematical self-correlation.
6. Publication-ready Figure 4A–F.

## Output directory

`/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04_singlecell`

Detailed log:

`/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04_singlecell/logs/Step4_singlecell.log`
