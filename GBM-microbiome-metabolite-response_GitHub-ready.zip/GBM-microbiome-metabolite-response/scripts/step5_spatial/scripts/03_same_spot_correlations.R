source(file.path(PACKAGE_DIR, "scripts", "00_utils.R"), local=FALSE)
x <- readRDS(file.path(CACHE_DIR,"05_scored_spots_cache.rds"))
scores <- as.data.table(x$scores)
programs <- x$programs
contexts <- x$contexts
Z <- x$Z

prog_cols <- grep("^(IPA_response|Succinate_response|TMAO_response|Propionate_response)__", names(scores), value=TRUE)
ctx_names <- unique(contexts$signature)

# overlap-removed context score per program/context using Z
overlap_removed_context <- function(pr, sv, sg, idx) {
  pg <- programs[program==pr & score_version==sv]$gene
  cg <- contexts[signature==sg]$gene
  g <- setdiff(cg, pg)
  g <- intersect(g, rownames(Z))
  if (!length(g)) return(rep(NA_real_, length(idx)))
  colMeans(Z[g, idx, drop=FALSE], na.rm=TRUE)
}

res <- list()
for (sl in unique(scores$slide)) {
  idx <- which(scores$slide==sl)
  pat <- unique(scores$patient[idx])[1]
  for (pc in prog_cols) {
    sp <- strsplit(pc,"__",fixed=TRUE)[[1]]
    pr <- sp[1]; sv <- sp[2]
    for (sg in ctx_names) {
      yy <- overlap_removed_context(pr, sv, sg, idx)
      rr <- safe_cor(scores[[pc]][idx], yy)
      res[[length(res)+1L]] <- data.table(slide=sl,patient=pat,program=pr,score_version=sv,context=sg,rho=rr,n_spots=length(idx),n_overlap=length(intersect(programs[program==pr & score_version==sv]$gene,contexts[signature==sg]$gene)))
    }
  }
}
slide <- rbindlist(res, fill=TRUE)
write_tsv(slide, file.path(TABLE_DIR,"05E_slide_same_spot_correlations.tsv"))

patient <- slide[, .(rho=median(rho,na.rm=TRUE),n_slides=.N), by=.(patient,program,score_version,context)]
write_tsv(patient, file.path(TABLE_DIR,"05F_patient_same_spot_correlations.tsv"))

tests <- patient[, .(n_patients=sum(is.finite(rho)),median_rho=median(rho,na.rm=TRUE),q25=quantile(rho,.25,na.rm=TRUE),q75=quantile(rho,.75,na.rm=TRUE),p_value=safe_wilcox0(rho)), by=.(program,score_version,context)]
tests[, FDR := bh(p_value), by=score_version]
write_tsv(tests, file.path(TABLE_DIR,"05G_patient_same_spot_tests.tsv"))
log_msg("SAME_SPOT_DONE", "Patient-level same-spot correlations complete.")
