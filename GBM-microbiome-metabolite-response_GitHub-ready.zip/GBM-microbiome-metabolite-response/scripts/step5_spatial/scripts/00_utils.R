suppressPackageStartupMessages({
  library(data.table)
  library(Matrix)
})

log_msg <- function(tag, ...) {
  x <- paste(..., collapse = " ")
  line <- sprintf("%s %-20s %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), tag, x)
  cat(line, "\n")
  if (exists("LOG_FILE", inherits = TRUE)) cat(line, "\n", file = LOG_FILE, append = TRUE)
}

write_tsv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  data.table::fwrite(as.data.table(x), path, sep = "\t", na = "NA")
}

robust_z <- function(x, clip = 2.5) {
  med <- median(x, na.rm = TRUE)
  sc <- mad(x, center = med, constant = 1.4826, na.rm = TRUE)
  if (!is.finite(sc) || sc <= 1e-10) sc <- sd(x, na.rm = TRUE)
  if (!is.finite(sc) || sc <= 1e-10) return(rep(0, length(x)))
  z <- (x - med) / sc
  pmax(-clip, pmin(clip, z))
}

safe_cor <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 20L || length(unique(x[ok])) < 3L || length(unique(y[ok])) < 3L) return(NA_real_)
  suppressWarnings(cor(x[ok], y[ok], method = "spearman"))
}

safe_wilcox0 <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) < 5L || all(abs(x) < 1e-12)) return(NA_real_)
  suppressWarnings(wilcox.test(x, mu = 0, exact = FALSE)$p.value)
}

get_assay_counts <- function(obj, assay = "Spatial") {
  if (!assay %in% names(obj@assays)) stop("Assay missing: ", assay)
  out <- tryCatch(SeuratObject::GetAssayData(obj, assay = assay, layer = "counts"), error = function(e) NULL)
  if (is.null(out)) out <- tryCatch(SeuratObject::GetAssayData(obj, assay = assay, slot = "counts"), error = function(e) NULL)
  if (is.null(out)) stop("Cannot obtain counts from assay ", assay)
  out
}

extract_image_coordinates <- function(obj) {
  imn <- names(obj@images)
  parts <- list()
  if (length(imn)) {
    for (nm in imn) {
      cc <- tryCatch(SeuratObject::GetTissueCoordinates(obj, image = nm), error = function(e) NULL)
      if (is.null(cc)) {
        cc <- tryCatch(as.data.frame(obj@images[[nm]]@coordinates), error = function(e) NULL)
      }
      if (is.null(cc) || !nrow(cc)) next
      cc <- as.data.table(cc, keep.rownames = "spot")
      if (!"spot" %in% names(cc)) cc[, spot := rownames(cc)]
      numcols <- names(cc)[vapply(cc, is.numeric, logical(1))]
      pref_x <- intersect(c("imagecol","col","x","pxl_col_in_fullres"), names(cc))
      pref_y <- intersect(c("imagerow","row","y","pxl_row_in_fullres"), names(cc))
      if (length(pref_x) && length(pref_y)) {
        cc[, x := get(pref_x[1])]
        cc[, y := get(pref_y[1])]
      } else if (length(numcols) >= 2L) {
        cc[, x := get(numcols[1])]
        cc[, y := get(numcols[2])]
      } else next
      cc[, slide := nm]
      parts[[length(parts)+1L]] <- cc[, .(spot, slide, x, y)]
    }
  }
  if (length(parts)) return(unique(rbindlist(parts, fill = TRUE), by = "spot"))
  NULL
}

pick_slide_column <- function(md) {
  cand <- c("slide","slide_id","sample","sample_id","section","section_id","orig.ident","library_id")
  hit <- intersect(cand, names(md))
  if (!length(hit)) return(NULL)
  hit[which.max(vapply(hit, function(z) uniqueN(md[[z]]), integer(1)))]
}

make_knn <- function(xy, k = 6L) {
  n <- nrow(xy)
  if (n <= k) return(NULL)
  if (requireNamespace("RANN", quietly = TRUE)) {
    return(RANN::nn2(xy, xy, k = k + 1L)$nn.idx[, -1, drop = FALSE])
  }
  if (requireNamespace("FNN", quietly = TRUE)) {
    return(FNN::get.knn(xy, k = k)$nn.index)
  }
  stop("RANN or FNN is required for neighborhood analysis. RANN is normally installed with Seurat.")
}

bh <- function(p) p.adjust(p, method = "BH")
