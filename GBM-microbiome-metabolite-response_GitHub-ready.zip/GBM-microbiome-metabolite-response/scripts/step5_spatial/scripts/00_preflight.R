preflight_packages <- function() {
  pkgs <- c("Rcpp", "RcppAnnoy", "SeuratObject", "Seurat")
  cat("=== STEP5 R ENVIRONMENT PREFLIGHT ===\n")
  cat("R executable:", file.path(R.home("bin"), "R"), "\n")
  cat("R version:", R.version.string, "\n")
  cat(".libPaths():\n")
  cat(paste0("  - ", .libPaths()), sep="\n")
  cat("\n")
  for (p in pkgs) {
    cat("Loading ", p, " ... ", sep="")
    suppressPackageStartupMessages(library(p, character.only=TRUE))
    cat("OK; version=", as.character(packageVersion(p)),
        "; path=", find.package(p), "\n", sep="")
  }
  cat("=== PREFLIGHT PASSED ===\n")
}
preflight_packages()
