source(file.path(PACKAGE_DIR, "scripts", "00_utils.R"), local = FALSE)

log_msg("START", "Step 5 GSE235672 spatial metabolite-response analysis")
programs <- fread(PROGRAM_FILE)
contexts <- fread(CONTEXT_FILE)
programs[, gene := toupper(gene)]
contexts[, gene := toupper(gene)]

cache_file <- file.path(CACHE_DIR, "05_spatial_target_gene_cache.rds")
candidate_audit <- file.path(TABLE_DIR, "05A_spatial_input_candidate_audit.tsv")

if (file.exists(cache_file)) {
  log_msg("CACHE", "Using existing target-gene spatial cache:", cache_file)
  dat <- readRDS(cache_file)
} else {
  cand <- unique(unlist(lapply(SEARCH_ROOTS[file.exists(SEARCH_ROOTS)], function(root) {
    list.files(root, pattern = "\\.rds$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  })))
  if (!length(cand)) stop("No RDS candidates found under configured search roots.")
  score <- integer(length(cand))
  score <- score + 5L*grepl("GSE235672", cand, ignore.case=TRUE)
  score <- score + 4L*grepl("04_GSE235672_patient_slide_TAM_colocalization", cand, fixed=TRUE)
  score <- score + 3L*grepl("spatial|visium", basename(cand), ignore.case=TRUE)
  score <- score + 1L*grepl("GBM", basename(cand), ignore.case=TRUE)
  ord <- order(score, decreasing=TRUE)
  cand <- cand[ord]
  aud <- data.table(path=cand, filename_score=score[ord], inspected=FALSE, is_seurat=NA, has_spatial=NA, n_spots=NA_integer_, n_images=NA_integer_, has_Pt_number=NA)
  plausible_paths <- character()
  plausible_objs <- list()
  for (i in seq_len(min(length(cand), 12L))) {
    p <- cand[i]
    log_msg("CANDIDATE", sprintf("[%d] %s", i, p))
    x <- tryCatch(readRDS(p), error=function(e) NULL)
    aud[i, inspected := TRUE]
    aud[i, is_seurat := inherits(x, "Seurat")]
    if (!inherits(x, "Seurat")) next
    aud[i, has_spatial := "Spatial" %in% names(x@assays)]
    aud[i, n_spots := ncol(x)]
    aud[i, n_images := length(x@images)]
    aud[i, has_Pt_number := "Pt_number" %in% colnames(x[[]])]
    plausible <- isTRUE(aud[i, has_spatial]) && isTRUE(aud[i, has_Pt_number]) &&
      aud[i, n_spots] >= 30000 && aud[i, n_spots] <= 60000
    if (plausible) {
      plausible_paths <- c(plausible_paths, p)
      plausible_objs[[p]] <- x
    } else {
      rm(x); gc()
    }
  }
  write_tsv(aud, candidate_audit)
  if (!length(plausible_paths)) stop("No plausible GSE235672 Seurat object was found. See ", candidate_audit)
  # Prefer a unique plausible object inside the previously used GSE235672 analysis directory.
  old_dir_hits <- plausible_paths[grepl("04_GSE235672_patient_slide_TAM_colocalization", plausible_paths, fixed=TRUE)]
  if (length(old_dir_hits) == 1L) {
    selected <- old_dir_hits
  } else if (length(plausible_paths) == 1L) {
    selected <- plausible_paths
  } else {
    stop("Multiple plausible GSE235672 objects were found; no object was selected silently. See ", candidate_audit)
  }
  obj <- plausible_objs[[selected]]
  log_msg("SELECTED_INPUT", selected)
  md <- as.data.table(obj[[]], keep.rownames="spot")
  if (!"Pt_number" %in% names(md)) stop("Selected object lacks Pt_number")
  md[, patient := as.character(Pt_number)]

  coords <- extract_image_coordinates(obj)
  if (is.null(coords)) {
    sc <- pick_slide_column(md)
    if (is.null(sc)) stop("Cannot derive slide identity from images or metadata.")
    md[, slide := as.character(get(sc))]
    xcol <- intersect(c("imagecol","col","x","pxl_col_in_fullres"), names(md))
    ycol <- intersect(c("imagerow","row","y","pxl_row_in_fullres"), names(md))
    if (!length(xcol) || !length(ycol)) stop("Cannot find spatial coordinates.")
    coords <- md[, .(spot, slide, x=as.numeric(get(xcol[1])), y=as.numeric(get(ycol[1])))]
  }
  meta <- merge(md[, .(spot, patient)], coords, by="spot", all.x=TRUE)
  if (anyNA(meta$x) || anyNA(meta$y)) {
    missing_n <- sum(!is.finite(meta$x) | !is.finite(meta$y))
    log_msg("WARNING", "Dropping spots without coordinates:", missing_n)
    meta <- meta[is.finite(x) & is.finite(y)]
  }
  slide_counts <- meta[, .N, by=slide]
  keep_slides <- slide_counts[N >= MIN_SPOTS_PER_SLIDE, slide]
  meta <- meta[slide %in% keep_slides]

  counts <- get_assay_counts(obj, "Spatial")
  rownames(counts) <- toupper(rownames(counts))
  target_genes <- unique(c(programs$gene, contexts$gene))
  present <- intersect(target_genes, rownames(counts))
  if (!length(present)) stop("None of the target genes are present in Spatial counts.")
  lib <- Matrix::colSums(counts)
  spots <- intersect(meta$spot, colnames(counts))
  meta <- meta[match(spots, spot)]
  lib <- lib[spots]
  subc <- counts[present, spots, drop=FALSE]
  logcpm <- log2(t(t(as.matrix(subc)) / lib) * 1e6 + 1)
  rm(counts, subc); gc()

  # robust z within slide and gene
  Z <- matrix(NA_real_, nrow=nrow(logcpm), ncol=ncol(logcpm), dimnames=dimnames(logcpm))
  for (sl in unique(meta$slide)) {
    idx <- which(meta$slide == sl)
    for (g in rownames(logcpm)) Z[g, idx] <- robust_z(logcpm[g, idx], CLIP_Z)
  }
  dat <- list(meta=meta, Z=Z, input_path=selected)
  saveRDS(dat, cache_file, compress=TRUE)
  rm(obj, logcpm); gc()
}

meta <- dat$meta
Z <- dat$Z
input_path <- dat$input_path

qc <- data.table(
  input_path=input_path,
  n_spots=nrow(meta),
  n_slides=uniqueN(meta$slide),
  n_patients=uniqueN(meta$patient),
  expected_spots=EXPECTED_SPOTS,
  expected_slides=EXPECTED_SLIDES,
  expected_patients=EXPECTED_PATIENTS,
  min_spots_per_slide=min(meta[, .N, by=slide]$N),
  max_spots_per_slide=max(meta[, .N, by=slide]$N)
)
write_tsv(qc, file.path(TABLE_DIR, "05B_spatial_input_qc.tsv"))
log_msg("QC", sprintf("spots=%d slides=%d patients=%d", qc$n_spots, qc$n_slides, qc$n_patients))

# Coverage
cov1 <- programs[, .(n_defined=.N, n_detected=sum(gene %in% rownames(Z)), detected_genes=paste(gene[gene %in% rownames(Z)],collapse=";"), missing_genes=paste(gene[!gene %in% rownames(Z)],collapse=";")), by=.(program,score_version)]
cov2 <- contexts[, .(n_defined=.N, n_detected=sum(gene %in% rownames(Z)), detected_genes=paste(gene[gene %in% rownames(Z)],collapse=";"), missing_genes=paste(gene[!gene %in% rownames(Z)],collapse=";")), by=signature]
cov1[, coverage := n_detected/n_defined]
cov2[, coverage := n_detected/n_defined]
write_tsv(cov1, file.path(TABLE_DIR, "05C_program_gene_coverage.tsv"))
write_tsv(cov2, file.path(TABLE_DIR, "05C_context_gene_coverage.tsv"))

score_from_def <- function(def) {
  d <- def[gene %in% rownames(Z)]
  if (!nrow(d)) return(rep(NA_real_, ncol(Z)))
  colMeans(sweep(Z[d$gene,,drop=FALSE], 1, d$direction, `*`), na.rm=TRUE)
}
context_score <- function(genes) {
  g <- intersect(genes, rownames(Z))
  if (!length(g)) return(rep(NA_real_, ncol(Z)))
  colMeans(Z[g,,drop=FALSE], na.rm=TRUE)
}

scores <- copy(meta)
for (pr in unique(programs$program)) {
  for (sv in unique(programs[program==pr]$score_version)) {
    nm <- paste(pr, sv, sep="__")
    scores[[nm]] <- score_from_def(programs[program==pr & score_version==sv])
  }
}
for (sg in unique(contexts$signature)) {
  scores[[paste0("CTX__",sg)]] <- context_score(contexts[signature==sg]$gene)
}

# Sensitivity scores
succ_dep_core <- c("MAPK1","MAPK3")
succ_dep_exp <- c("GOT1","GPT","MAPK1","MAPK3")
scores[["Succinate_response_depleted__causal_core"]] <- context_score(succ_dep_core)
scores[["Succinate_response_depleted__expanded"]] <- context_score(succ_dep_exp)

# TMAO immune-anchor depleted expanded
tmao_def <- programs[program=="TMAO_response" & score_version=="expanded"]
tmao_def <- tmao_def[!gene %in% c("IL1B","IL6","IL12A","TNF","CD14","CD163","LCN2")]
scores[["TMAO_response_anchor_depleted__expanded"]] <- score_from_def(tmao_def)

fwrite(scores, file.path(TABLE_DIR,"05D_spot_scores.tsv.gz"), sep="\t", compress="gzip", na="NA")
saveRDS(list(scores=scores, programs=programs, contexts=contexts, Z=Z), file.path(CACHE_DIR,"05_scored_spots_cache.rds"), compress=TRUE)
log_msg("SCORING_DONE", "Spot scores written.")
