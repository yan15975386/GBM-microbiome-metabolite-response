args <- commandArgs(trailingOnly = FALSE)
file_arg <- sub("^--file=", "", args[grep("^--file=", args)][1])
PACKAGE_DIR <- normalizePath(file.path(dirname(file_arg), ".."), mustWork=TRUE)
source(file.path(PACKAGE_DIR,"scripts","00_preflight.R"), local=FALSE)

candidate <- "/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/04_GSE235672_patient_slide_TAM_colocalization"
cat("\n=== SEARCHING CANDIDATE RDS FILES ===\n")
rr <- list.files(candidate, pattern="\\.rds$", recursive=TRUE, full.names=TRUE, ignore.case=TRUE)
rr <- rr[order(!grepl("GSE235672|spatial|visium", rr, ignore.case=TRUE), nchar(rr))]
print(head(rr, 30))

if (length(rr)) {
  cat("\n=== TEST-READING FIRST RANKED CANDIDATES ===\n")
  for (f in head(rr, 6)) {
    cat("\nFILE:", f, "\n")
    x <- tryCatch(readRDS(f), error=function(e)e)
    if (inherits(x,"error")) {
      cat("READ_ERROR:", conditionMessage(x), "\n")
    } else {
      cat("READ_OK class=", paste(class(x),collapse=";"), "\n", sep="")
      if (inherits(x,"Seurat")) {
        cat("dims=", nrow(x), " x ", ncol(x), "\n", sep="")
        cat("assays=", paste(names(x@assays),collapse=";"), "\n", sep="")
        cat("images=", length(x@images), "\n", sep="")
        cat("Pt_number=", "Pt_number" %in% colnames(x[[]]), "\n", sep="")
      }
      rm(x); gc()
    }
  }
}
