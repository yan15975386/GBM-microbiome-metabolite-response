if (!exists("PACKAGE_DIR", inherits = FALSE)) stop("PACKAGE_DIR was not initialized by the runner.")
PROJECT_ROOT <- "/media/desk16/iy12923/GBM_new/gut"
OUT_ROOT <- file.path(PROJECT_ROOT, "gutGBM_microbiome_metabolite_rebuild", "05_spatial_v3_fixed")
TABLE_DIR <- file.path(OUT_ROOT, "tables")
FIG_DIR <- file.path(OUT_ROOT, "figures")
CACHE_DIR <- file.path(OUT_ROOT, "cache")
LOG_DIR <- file.path(OUT_ROOT, "logs")
dir.create(TABLE_DIR, recursive=TRUE, showWarnings=FALSE)
dir.create(FIG_DIR, recursive=TRUE, showWarnings=FALSE)
dir.create(CACHE_DIR, recursive=TRUE, showWarnings=FALSE)
dir.create(LOG_DIR, recursive=TRUE, showWarnings=FALSE)
LOG_FILE <- file.path(LOG_DIR, "Step5_spatial.log")

EXPECTED_SPOTS <- 44829L
EXPECTED_SLIDES <- 34L
EXPECTED_PATIENTS <- 18L
MIN_SPOTS_PER_SLIDE <- 100L
PRIMARY_K <- 6L
SENS_K <- c(4L, 12L)
CLIP_Z <- 2.5

PROGRAM_FILE <- file.path(PACKAGE_DIR, "config", "01_programs.tsv")
CONTEXT_FILE <- file.path(PACKAGE_DIR, "config", "02_context_signatures.tsv")

SEARCH_ROOTS <- c(
  file.path(PROJECT_ROOT, "gutGBM_JMN_rebuild", "04_GSE235672_patient_slide_TAM_colocalization"),
  file.path(PROJECT_ROOT, "gutGBM_JMN_rebuild"),
  PROJECT_ROOT,
  "/media/desk16/iy12923/GBM_new/source"
)
