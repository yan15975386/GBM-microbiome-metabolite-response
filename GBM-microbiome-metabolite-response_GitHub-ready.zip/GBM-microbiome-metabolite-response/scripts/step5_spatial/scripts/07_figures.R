suppressPackageStartupMessages({library(data.table); library(ggplot2)})
source(file.path(PACKAGE_DIR, "scripts", "00_utils.R"), local=FALSE)

scores <- fread(file.path(TABLE_DIR,"05D_spot_scores.tsv.gz"))
same <- fread(file.path(TABLE_DIR,"05G_patient_same_spot_tests.tsv"))
nei <- fread(file.path(TABLE_DIR,"05J_patient_neighborhood_tests.tsv"))
joint <- fread(file.path(TABLE_DIR,"05K_TMAO_joint_TAM_MES_niche_patient.tsv"))
succ <- fread(file.path(TABLE_DIR,"05L_Succinate_full_vs_depleted_patient.tsv"))

# representative slide: high variance across key scores
key <- c("IPA_response__causal_core","Succinate_response__causal_core","TMAO_response__causal_core","CTX__TAM","CTX__MES_like")
varsl <- scores[, .(v=sum(vapply(.SD,var,numeric(1),na.rm=TRUE))), by=slide, .SDcols=intersect(key,names(scores))]
rep_slide <- varsl[which.max(v),slide]
d <- scores[slide==rep_slide]
long <- melt(d[,c("x","y","IPA_response__causal_core","Succinate_response__causal_core","TMAO_response__causal_core","CTX__TAM","CTX__MES_like"),with=FALSE],id.vars=c("x","y"),variable.name="score",value.name="value")
p1 <- ggplot(long,aes(x=x,y=y,fill=value))+geom_point(shape=21,size=.7,stroke=0)+coord_equal()+facet_wrap(~score,nrow=1)+scale_y_reverse()+theme_void(base_size=9)+labs(title=paste("Representative GSE235672 slide:",rep_slide))
ggsave(file.path(FIG_DIR,"Figure5A_representative_spatial_maps.png"),p1,width=13,height=3.2,dpi=300)
ggsave(file.path(FIG_DIR,"Figure5A_representative_spatial_maps.pdf"),p1,width=13,height=3.2)

# same spot heatmap
h <- same[score_version=="causal_core" & context %in% c("TAM","Inflammatory_response","MES_like","Hypoxia")]
p2 <- ggplot(h,aes(x=context,y=program,fill=median_rho))+geom_tile()+geom_text(aes(label=sprintf("%.2f",median_rho)),size=3)+scale_fill_gradient2(midpoint=0)+theme_minimal(base_size=10)+labs(x=NULL,y=NULL,fill="Median patient rho",title="Patient-level within-slide spatial concordance")
ggsave(file.path(FIG_DIR,"Figure5B_same_spot_correlations.png"),p2,width=7,height=4,dpi=300)
ggsave(file.path(FIG_DIR,"Figure5B_same_spot_correlations.pdf"),p2,width=7,height=4)

# neighborhood k6
h2 <- nei[score_version=="causal_core" & k==PRIMARY_K & context %in% c("TAM","Inflammatory_response","MES_like","Hypoxia")]
p3 <- ggplot(h2,aes(x=context,y=program,fill=median_rho))+geom_tile()+geom_text(aes(label=sprintf("%.2f",median_rho)),size=3)+scale_fill_gradient2(midpoint=0)+theme_minimal(base_size=10)+labs(x=NULL,y=NULL,fill="Median patient rho",title="k=6 neighboring-niche concordance")
ggsave(file.path(FIG_DIR,"Figure5C_neighborhood_correlations.png"),p3,width=7,height=4,dpi=300)
ggsave(file.path(FIG_DIR,"Figure5C_neighborhood_correlations.pdf"),p3,width=7,height=4)

# TMAO joint niche
j <- joint[quantile_threshold==.75]
p4 <- ggplot(j,aes(x=score_version,y=effect))+geom_boxplot(outlier.shape=NA)+geom_jitter(width=.08,size=1.5)+geom_hline(yintercept=0,lty=2)+theme_minimal(base_size=10)+labs(x=NULL,y="TMAO score: joint TAM+MES niche minus other spots",title="TMAO enrichment in joint TAM–MES spatial niches")
ggsave(file.path(FIG_DIR,"Figure5D_TMAO_joint_TAM_MES.png"),p4,width=5.5,height=4,dpi=300)
ggsave(file.path(FIG_DIR,"Figure5D_TMAO_joint_TAM_MES.pdf"),p4,width=5.5,height=4)

# Succinate full vs depleted
s <- succ[score_version=="causal_core"]
sl <- melt(s,id.vars=c("patient","score_version","program_version","context"),measure.vars=c("same_spot_rho","neighbor_rho"),variable.name="analysis",value.name="rho")
p5 <- ggplot(sl,aes(x=program_version,y=rho))+geom_boxplot(outlier.shape=NA)+geom_jitter(width=.08,size=1)+geom_hline(yintercept=0,lty=2)+facet_grid(analysis~context)+theme_minimal(base_size=8)+labs(x=NULL,y="Patient-level rho",title="Succinate full program versus cytokine-depleted residual")
ggsave(file.path(FIG_DIR,"Figure5E_Succinate_full_vs_depleted.png"),p5,width=10,height=6,dpi=300)
ggsave(file.path(FIG_DIR,"Figure5E_Succinate_full_vs_depleted.pdf"),p5,width=10,height=6)

log_msg("FIGURES_DONE","Figure 5 panels generated.")
