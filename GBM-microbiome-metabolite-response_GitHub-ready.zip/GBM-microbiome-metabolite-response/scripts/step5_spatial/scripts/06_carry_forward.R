source(file.path(PACKAGE_DIR, "scripts", "00_utils.R"), local=FALSE)
same <- fread(file.path(TABLE_DIR,"05G_patient_same_spot_tests.tsv"))
nei <- fread(file.path(TABLE_DIR,"05J_patient_neighborhood_tests.tsv"))
joint <- fread(file.path(TABLE_DIR,"05K_TMAO_joint_TAM_MES_niche_tests.tsv"))
succ <- fread(file.path(TABLE_DIR,"05L_Succinate_full_vs_depleted_tests.tsv"))

core_targets <- data.table(
  axis=c("IPA_response","Succinate_response","TMAO_response","Propionate_response"),
  prior_role=c("Primary","Primary_mechanistic_qualified","Primary","Secondary"),
  spatial_primary_context=c("TAM;Inflammatory_response;MES_like","TAM;Inflammatory_response;MES_like","TAM;Inflammatory_response;MES_like","TAM;Inflammatory_response")
)
summ <- list()
for (i in seq_len(nrow(core_targets))) {
  a <- core_targets$axis[i]
  s <- same[program==a & score_version=="causal_core" & context %in% unlist(strsplit(core_targets$spatial_primary_context[i],";",fixed=TRUE))]
  n <- nei[program==a & score_version=="causal_core" & k==PRIMARY_K & context %in% unlist(strsplit(core_targets$spatial_primary_context[i],";",fixed=TRUE))]
  summ[[i]] <- data.table(
    axis=a,
    prior_role=core_targets$prior_role[i],
    same_spot_median_rho=paste(sprintf("%s:%.3f",s$context,s$median_rho),collapse=";"),
    same_spot_FDR=paste(sprintf("%s:%.3g",s$context,s$FDR),collapse=";"),
    neighbor_median_rho=paste(sprintf("%s:%.3f",n$context,n$median_rho),collapse=";"),
    neighbor_FDR=paste(sprintf("%s:%.3g",n$context,n$FDR),collapse=";")
  )
}
cf <- rbindlist(summ)
write_tsv(cf,file.path(TABLE_DIR,"05M_spatial_carry_forward.tsv"))
log_msg("CARRY_FORWARD_DONE","Summary table written.")
