source(file.path(PACKAGE_DIR, "scripts", "00_utils.R"), local=FALSE)
x <- readRDS(file.path(CACHE_DIR,"05_scored_spots_cache.rds"))
scores <- as.data.table(x$scores)

# TMAO in joint TAM + MES high niches; thresholds fixed a priori as sensitivity set
out <- list()
for (sl in unique(scores$slide)) {
  d <- scores[slide==sl]
  pat <- unique(d$patient)[1]
  for (q in c(.70,.75,.80)) {
    th_tam <- quantile(d$CTX__TAM,q,na.rm=TRUE)
    th_mes <- quantile(d$CTX__MES_like,q,na.rm=TRUE)
    joint <- d$CTX__TAM>=th_tam & d$CTX__MES_like>=th_mes
    for (sv in c("causal_core","expanded")) {
      pc <- paste("TMAO_response",sv,sep="__")
      if (!pc %in% names(d)) next
      eff <- median(d[[pc]][joint],na.rm=TRUE)-median(d[[pc]][!joint],na.rm=TRUE)
      out[[length(out)+1L]] <- data.table(slide=sl,patient=pat,quantile_threshold=q,score_version=sv,n_joint=sum(joint),effect=eff)
    }
  }
}
joint_slide <- rbindlist(out)
joint_pat <- joint_slide[,.(effect=median(effect,na.rm=TRUE),n_slides=.N,n_joint=sum(n_joint)),by=.(patient,quantile_threshold,score_version)]
joint_test <- joint_pat[,.(n_patients=.N,median_effect=median(effect,na.rm=TRUE),p_value=safe_wilcox0(effect)),by=.(quantile_threshold,score_version)]
joint_test[,FDR:=bh(p_value),by=score_version]
write_tsv(joint_slide,file.path(TABLE_DIR,"05K_TMAO_joint_TAM_MES_niche_slide.tsv"))
write_tsv(joint_pat,file.path(TABLE_DIR,"05K_TMAO_joint_TAM_MES_niche_patient.tsv"))
write_tsv(joint_test,file.path(TABLE_DIR,"05K_TMAO_joint_TAM_MES_niche_tests.tsv"))

# Succinate full vs cytokine-depleted; same-spot + neighborhood k6 for TAM, Inflammatory, Proinflammatory_TAM, MES
targets <- c("TAM","Inflammatory_response","MES_like")
res <- list()
for (sl in unique(scores$slide)) {
  d <- scores[slide==sl]; pat <- unique(d$patient)[1]
  xy <- as.matrix(d[,.(x,y)]); nn <- make_knn(xy,PRIMARY_K)
  for (sv in c("causal_core","expanded")) {
    full <- paste("Succinate_response",sv,sep="__")
    dep <- paste("Succinate_response_depleted",sv,sep="__")
    for (sg in targets) {
      cc <- paste0("CTX__",sg)
      if (!all(c(full,dep,cc)%in%names(d))) next
      neigh <- rowMeans(matrix(d[[cc]][nn],nrow=nrow(nn),ncol=ncol(nn)),na.rm=TRUE)
      for (ver in c("full","depleted")) {
        pc <- if (ver=="full") full else dep
        res[[length(res)+1L]] <- data.table(slide=sl,patient=pat,score_version=sv,program_version=ver,context=sg,same_spot_rho=safe_cor(d[[pc]],d[[cc]]),neighbor_rho=safe_cor(d[[pc]],neigh))
      }
    }
  }
}
ss <- rbindlist(res)
pp <- ss[,.(same_spot_rho=median(same_spot_rho,na.rm=TRUE),neighbor_rho=median(neighbor_rho,na.rm=TRUE)),by=.(patient,score_version,program_version,context)]
tt <- pp[,.(n_patients=.N,median_same_spot_rho=median(same_spot_rho,na.rm=TRUE),same_spot_p=safe_wilcox0(same_spot_rho),median_neighbor_rho=median(neighbor_rho,na.rm=TRUE),neighbor_p=safe_wilcox0(neighbor_rho)),by=.(score_version,program_version,context)]
tt[,same_spot_FDR:=bh(same_spot_p),by=score_version]
tt[,neighbor_FDR:=bh(neighbor_p),by=score_version]
write_tsv(ss,file.path(TABLE_DIR,"05L_Succinate_full_vs_depleted_slide.tsv"))
write_tsv(pp,file.path(TABLE_DIR,"05L_Succinate_full_vs_depleted_patient.tsv"))
write_tsv(tt,file.path(TABLE_DIR,"05L_Succinate_full_vs_depleted_tests.tsv"))
log_msg("TARGETED_DONE","TMAO joint niche and Succinate depletion analyses complete.")
