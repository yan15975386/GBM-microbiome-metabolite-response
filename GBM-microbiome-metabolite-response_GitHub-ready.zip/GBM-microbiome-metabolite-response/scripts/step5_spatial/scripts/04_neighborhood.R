source(file.path(PACKAGE_DIR, "scripts", "00_utils.R"), local=FALSE)
x <- readRDS(file.path(CACHE_DIR,"05_scored_spots_cache.rds"))
scores <- as.data.table(x$scores)
programs <- x$programs
contexts <- x$contexts
Z <- x$Z
prog_cols <- grep("^(IPA_response|Succinate_response|TMAO_response|Propionate_response)__", names(scores), value=TRUE)
ctx_names <- unique(contexts$signature)
ks <- c(PRIMARY_K, SENS_K)

get_or_ctx <- function(pr,sv,sg,idx) {
  pg <- programs[program==pr & score_version==sv]$gene
  cg <- setdiff(contexts[signature==sg]$gene, pg)
  cg <- intersect(cg, rownames(Z))
  if (!length(cg)) return(rep(NA_real_, length(idx)))
  colMeans(Z[cg,idx,drop=FALSE],na.rm=TRUE)
}

out <- list()
for (sl in unique(scores$slide)) {
  idx <- which(scores$slide==sl)
  xy <- as.matrix(scores[idx,.(x,y)])
  pat <- unique(scores$patient[idx])[1]
  for (k in ks) {
    nn <- make_knn(xy,k)
    if (is.null(nn)) next
    for (pc in prog_cols) {
      sp <- strsplit(pc,"__",fixed=TRUE)[[1]]; pr<-sp[1]; sv<-sp[2]
      pv <- scores[[pc]][idx]
      for (sg in ctx_names) {
        cv <- get_or_ctx(pr,sv,sg,idx)
        neigh <- rowMeans(matrix(cv[nn],nrow=nrow(nn),ncol=ncol(nn)),na.rm=TRUE)
        rr <- safe_cor(pv,neigh)
        out[[length(out)+1L]] <- data.table(slide=sl,patient=pat,k=k,program=pr,score_version=sv,context=sg,rho=rr,n_spots=length(idx))
      }
    }
  }
}
slide <- rbindlist(out,fill=TRUE)
write_tsv(slide,file.path(TABLE_DIR,"05H_slide_neighborhood_correlations.tsv"))
patient <- slide[,.(rho=median(rho,na.rm=TRUE),n_slides=.N),by=.(patient,k,program,score_version,context)]
write_tsv(patient,file.path(TABLE_DIR,"05I_patient_neighborhood_correlations.tsv"))
tests <- patient[,.(n_patients=sum(is.finite(rho)),median_rho=median(rho,na.rm=TRUE),q25=quantile(rho,.25,na.rm=TRUE),q75=quantile(rho,.75,na.rm=TRUE),p_value=safe_wilcox0(rho)),by=.(k,program,score_version,context)]
tests[,FDR:=bh(p_value),by=.(k,score_version)]
write_tsv(tests,file.path(TABLE_DIR,"05J_patient_neighborhood_tests.tsv"))
log_msg("NEIGHBORHOOD_DONE","k=",paste(ks,collapse=","))
