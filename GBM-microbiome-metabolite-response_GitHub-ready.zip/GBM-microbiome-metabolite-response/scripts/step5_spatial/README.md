# Step 5 — GSE235672 spatial metabolite-linked host-response localization

## Main questions
1. Does IPA-response spatially avoid TAM / inflammatory / MES-rich niches?
2. Does TMAO-response co-localize with TAM-rich and MES-like regions, including joint TAM–MES niches?
3. Does the full Succinate-response localize to inflammatory/TAM niches, while its cytokine-depleted residual loses this localization?
4. Propionate is retained as a secondary myeloid-associated comparison.

## Statistical design
- Dataset target: GSE235672 Visium.
- Expected structure from prior analysis: ~44,829 spots, 34 slides, 18 patients.
- Patient identity: `Pt_number`.
- Slides with <100 spots are excluded.
- No spot-level P values are used for primary inference.
- Within each slide, spot-level Spearman correlations are calculated.
- Slide estimates are collapsed to one median estimate per patient.
- Primary tests use the patient-level estimates against zero (Wilcoxon signed-rank).
- BH correction is applied within each analysis family.
- k=6 is the primary spatial neighborhood definition; k=4 and k=12 are sensitivity analyses.
- Program/context gene overlap is removed from the context signature before correlation.
- Spatial results are interpreted as co-localization / neighborhood concordance, not cell-cell interaction or metabolite concentration.

## Input discovery
The pipeline searches existing GBM project folders for a Seurat RDS containing:
- `Spatial` assay
- `Pt_number`
- approximately the expected GSE235672 spot structure

The old GSE235672 analysis directory is prioritized:
`/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/04_GSE235672_patient_slide_TAM_colocalization`

If more than one plausible object remains, the pipeline stops after writing:
`05A_spatial_input_candidate_audit.tsv`

No candidate is silently substituted.

## Output root
`/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/05_spatial`

## Main outputs
- 05A_spatial_input_candidate_audit.tsv
- 05B_spatial_input_qc.tsv
- 05C_program_gene_coverage.tsv
- 05D_spot_scores.tsv.gz
- 05E_slide_same_spot_correlations.tsv
- 05F_patient_same_spot_correlations.tsv
- 05G_patient_same_spot_tests.tsv
- 05H_slide_neighborhood_correlations.tsv
- 05I_patient_neighborhood_correlations.tsv
- 05J_patient_neighborhood_tests.tsv
- 05K_TMAO_joint_TAM_MES_niche.tsv
- 05L_Succinate_full_vs_depleted.tsv
- 05M_spatial_carry_forward.tsv

## Notes
- Propionate uses only genes actually detected in the spatial object; missing genes are not represented by zero placeholders.
- The original full programs remain the primary definitions. Depleted scores are sensitivity analyses only.


## v2 environment fix
v2 explicitly preloads `Rcpp`, `RcppAnnoy`, `SeuratObject`, and `Seurat` before any RDS is opened.
The console log records the R executable/version, `.libPaths()`, package versions, and exact package installation paths.

A standalone diagnostic is included:
`scripts/00_diagnose_environment_and_object.R`

## v3 FIXED definitions
This version supersedes v1/v2 for final analysis.
It restores the exact Step 3 / Step 4 / Step 4B program definitions and the exact Step 3 context signatures.
Most importantly, the TMAO causal-core is:
CD44(+), HBA1(+), IL1B(+), IL6(+), LCN2(+), SMN1(+), SMURF2(-), TGFBR1(+).
CD14, CD163, IL12A and TNF are expanded-only for TMAO.
Outputs are written to `05_spatial_v3_fixed` and do not overwrite the earlier audit run.
