# Analysis scripts

The subdirectories preserve the step-specific analysis packages used for the manuscript:

- `step3_bulk/`: TCGA-GBM and GSE16011 bulk transcriptomic analyses.
- `step4_singlecell/`: GSE182109 patient × cell-type pseudobulk localisation.
- `step4B_robustness/`: leave-one-gene-out and lineage/cytokine-depletion analyses.
- `step5_spatial/`: GSE235672 same-spot, neighbourhood and targeted spatial analyses.
- `step6_specificity/`: expression-matched random-program and spatial-permutation analyses.

The scripts are preserved as executed for auditability. Some step-specific configuration files
contain original server paths and therefore must be edited when reproducing the workflow in a
different environment. Raw TCGA/GEO data are not redistributed in this repository.
