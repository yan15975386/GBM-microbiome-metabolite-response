suppressPackageStartupMessages({ library(data.table); library(ggplot2) })
if (!exists("PACKAGE_DIR")) {
  cmd0 <- commandArgs(trailingOnly=FALSE); fa0 <- sub("^--file=", "", cmd0[grepl("^--file=",cmd0)][1]); source(file.path(dirname(normalizePath(fa0)), "00_config.R"))
}
readt <- function(x) fread(file.path(TABLE_DIR,x))
save_plot <- function(p,name,w=9,h=6){ ggsave(file.path(FIGURE_DIR,paste0(name,".png")),p,width=w,height=h,dpi=300); ggsave(file.path(FIGURE_DIR,paste0(name,".pdf")),p,width=w,height=h) }

loo <- readt("04B_05_leave_one_gene_out_localization.tsv")
orig <- readt("04B_03_original_localization_recomputed.tsv")
core_loo <- loo[score_version=="host_causal_core"]
core_orig <- orig[score_version=="host_causal_core",.(program,original=median_paired_difference)]
p1 <- ggplot(core_loo,aes(x=median_paired_difference,y=program)) + geom_vline(xintercept=0,lty=2) + geom_point(aes(shape=dropped_gene),size=2.2,alpha=.8) + geom_point(data=core_orig,aes(x=original,y=program),inherit.aes=FALSE,size=4) + labs(x="Median paired TAM − Tumor score difference",y=NULL,title="Leave-one-gene-out localization robustness") + theme_bw(base_size=11) + theme(legend.position="none")
save_plot(p1,"Figure4B_A_LOO_localization",9,5)

contrib <- readt("04B_04_gene_level_TAM_vs_Tumor_contributions.tsv")[score_version=="host_causal_core"]
p2 <- ggplot(contrib,aes(x=mean_program_effect_contribution,y=reorder(gene,mean_program_effect_contribution))) + geom_col() + facet_wrap(~program,scales="free_y") + geom_vline(xintercept=0,lty=2) + labs(x="Contribution to mean TAM − Tumor program difference",y=NULL,title="Gene-level signed contributions") + theme_bw(base_size=10)
save_plot(p2,"Figure4B_B_gene_contributions",10,8)

dep <- readt("04B_10_depleted_TAM_vs_Tumor_localization.tsv")[score_version=="host_causal_core",.(program,variant=scheme,effect=median_paired_difference)]
o <- orig[score_version=="host_causal_core",.(program,variant="original",effect=median_paired_difference)]
dp <- rbind(o,dep,fill=TRUE); dp[,variant:=factor(variant,levels=c("original","cytokine_depleted","immune_anchor_depleted"))]
p3 <- ggplot(dp,aes(x=effect,y=program,shape=variant)) + geom_vline(xintercept=0,lty=2) + geom_point(size=3,position=position_dodge(width=.4)) + labs(x="Median paired TAM − Tumor score difference",y=NULL,title="Prespecified depletion sensitivity") + theme_bw(base_size=11)
save_plot(p3,"Figure4B_C_depletion_localization",9,5)

tam <- readt("04B_11_depleted_TAM_state_correlations.tsv")[score_version=="host_causal_core" & signature=="Proinflammatory_TAM",.(program,variant=scheme,rho)]
# Add original Step4 correlation if available.
orig_path <- file.path(STEP4_ROOT,"tables","04I_TAM_program_state_correlations_overlap_removed.tsv")
if (file.exists(orig_path)) { oo<-fread(orig_path)[score_version=="host_causal_core" & signature=="Proinflammatory_TAM",.(program,variant="original",rho)]; tam<-rbind(oo,tam,fill=TRUE) }
tam[,variant:=factor(variant,levels=c("original","cytokine_depleted","immune_anchor_depleted"))]
p4 <- ggplot(tam,aes(x=rho,y=program,shape=variant)) + geom_vline(xintercept=0,lty=2) + geom_point(size=3,position=position_dodge(width=.4)) + xlim(-1,1) + labs(x="Spearman rho with overlap-removed Proinflammatory TAM score",y=NULL,title="TAM-state robustness after gene depletion") + theme_bw(base_size=11)
save_plot(p4,"Figure4B_D_Proinflammatory_TAM_robustness",9,5)
cat("Step4B figures complete\n")
