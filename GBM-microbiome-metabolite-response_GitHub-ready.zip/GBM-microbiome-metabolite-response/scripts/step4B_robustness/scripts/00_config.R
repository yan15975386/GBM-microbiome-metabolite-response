options(stringsAsFactors = FALSE)
set.seed(20260902)

if (!exists("PACKAGE_DIR", inherits = FALSE)) {
  cmd <- commandArgs(trailingOnly = FALSE)
  file_arg <- sub("^--file=", "", cmd[grepl("^--file=", cmd)])
  if (length(file_arg)) {
    script_file <- normalizePath(file_arg[1], mustWork = TRUE)
    PACKAGE_DIR <- dirname(dirname(script_file))
  } else {
    PACKAGE_DIR <- normalizePath(getwd(), mustWork = TRUE)
  }
}
PACKAGE_DIR <- normalizePath(PACKAGE_DIR, mustWork = TRUE)

STEP4_ROOT <- "/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04_singlecell"
OUT_ROOT <- "/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04B_singlecell_robustness"
TABLE_DIR <- file.path(OUT_ROOT, "tables")
FIGURE_DIR <- file.path(OUT_ROOT, "figures")
LOG_DIR <- file.path(OUT_ROOT, "logs")
CACHE_DIR <- file.path(OUT_ROOT, "cache")
for (d in c(TABLE_DIR, FIGURE_DIR, LOG_DIR, CACHE_DIR)) dir.create(d, recursive=TRUE, showWarnings=FALSE)

OBJECT_CANDIDATES <- c(
  "/media/desk16/iy12923/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_build_from_local_10x/GSE182109_GBM_broad_annotated_lean.rds",
  path.expand("~/GBM_new/gut/gutGBM_JMN_rebuild/03A_GSE182109_build_from_local_10x/GSE182109_GBM_broad_annotated_lean.rds")
)
PROGRAM_FILE <- file.path(PACKAGE_DIR, "resources", "03A_metabolite_response_programs.tsv")
TAM_STATE_FILE <- file.path(PACKAGE_DIR, "resources", "04A_TAM_state_signatures.tsv")
CONTEXT_FILE <- file.path(PACKAGE_DIR, "resources", "03A_bulk_context_signatures.tsv")
DEPLETION_FILE <- file.path(PACKAGE_DIR, "resources", "04B_predefined_depletion_sets.tsv")

STEP4_META <- file.path(STEP4_ROOT, "tables", "04A_cell_metadata_analysis_labels.tsv.gz")
STEP4_ELIGIBLE <- file.path(STEP4_ROOT, "tables", "04C_patient_celltype_groups_eligible.tsv")
STEP4_ORIGINAL_SCORES <- file.path(STEP4_ROOT, "tables", "04D_patient_celltype_program_scores.tsv")
STEP4_ORIGINAL_CONTRASTS <- file.path(STEP4_ROOT, "tables", "04F_patient_paired_localization_contrasts.tsv")

CACHE_FILE <- file.path(CACHE_DIR, "04B_selected_gene_patient_celltype_cache.rds")
MIN_GENES_PER_SCORE <- 2L
MIN_PATIENTS_FOR_CORRELATION <- 8L
TAM_LABEL <- "TAM/myeloid"
TUMOR_LABEL <- "Tumor-like"
