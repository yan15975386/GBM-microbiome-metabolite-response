suppressPackageStartupMessages({
  library(data.table)
  library(Matrix)
  library(SeuratObject)
})
if (!exists("PACKAGE_DIR")) {
  cmd0 <- commandArgs(trailingOnly=FALSE); fa0 <- sub("^--file=", "", cmd0[grepl("^--file=",cmd0)][1]); source(file.path(dirname(normalizePath(fa0)), "00_config.R"))
}

LOG_FILE <- file.path(LOG_DIR, "Step4B_robustness.log")
logmsg <- function(stage, ...) {
  txt <- paste(..., collapse=" ")
  line <- sprintf("%s  %-22s %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), stage, txt)
  cat(line, "\n"); cat(line, "\n", file=LOG_FILE, append=TRUE)
}
write_tsv <- function(x, name) fwrite(x, file.path(TABLE_DIR, name), sep="\t", na="NA", quote=FALSE)
clean_gene <- function(x) toupper(trimws(as.character(x)))
zsafe <- function(x) { s <- sd(x, na.rm=TRUE); if (!is.finite(s) || s==0) return(rep(0,length(x))); (x-mean(x,na.rm=TRUE))/s }
find_first <- function(x) { y <- x[file.exists(x)]; if (!length(y)) stop("No input object found among configured candidates"); normalizePath(y[1]) }

programs <- fread(PROGRAM_FILE); programs[, host_gene := clean_gene(host_gene)]
tam_states <- fread(TAM_STATE_FILE); tam_states[, gene := clean_gene(gene)]
contexts <- fread(CONTEXT_FILE); contexts[, gene := clean_gene(gene)]
tumor_states <- contexts[signature %in% c("MES_like","AC_like","OPC_like","NPC_like"), .(signature,gene)]
depletion <- fread(DEPLETION_FILE); depletion[, gene := clean_gene(gene)]

for (p in c(STEP4_META, STEP4_ELIGIBLE, STEP4_ORIGINAL_SCORES, STEP4_ORIGINAL_CONTRASTS)) if (!file.exists(p)) stop("Required Step4 output missing: ", p)
meta <- fread(STEP4_META)
eligible <- fread(STEP4_ELIGIBLE)
meta[, group_id := paste(patient_id, broad_cell_type, sep="|||")]
meta <- meta[group_id %in% eligible$group_id]
eligible <- eligible[match(unique(meta$group_id), group_id)]
if (anyNA(eligible$group_id)) stop("Eligible group reconciliation failed")

all_required <- unique(c(programs$host_gene, tam_states$gene, tumor_states$gene))
logmsg("START", "Step4B lineage robustness; selected genes=", length(all_required), "; eligible groups=", nrow(eligible))

if (file.exists(CACHE_FILE)) {
  logmsg("CACHE_LOAD_START", CACHE_FILE)
  cache <- readRDS(CACHE_FILE)
  gene_z <- cache$gene_z; eligible <- cache$eligible
  logmsg("CACHE_LOAD_DONE", "genes=", nrow(gene_z), "; groups=", ncol(gene_z))
} else {
  obj_path <- find_first(OBJECT_CANDIDATES)
  logmsg("READ_RDS_START", obj_path)
  obj <- readRDS(obj_path)
  logmsg("READ_RDS_DONE", "class=", paste(class(obj), collapse="/"))
  if (!"RNA" %in% Assays(obj)) stop("RNA assay missing")
  counts <- tryCatch(SeuratObject::LayerData(obj, assay="RNA", layer="counts"), error=function(e) NULL)
  if (is.null(counts)) counts <- tryCatch(SeuratObject::GetAssayData(obj, assay="RNA", slot="counts"), error=function(e) NULL)
  if (is.null(counts)) stop("Could not retrieve RNA raw counts")
  if (!inherits(counts,"Matrix")) counts <- as(counts,"dgCMatrix")
  logmsg("COUNTS_READY", "genes=", nrow(counts), "; cells=", ncol(counts))

  idx <- match(meta$cell_id, colnames(counts))
  if (anyNA(idx)) stop(sum(is.na(idx)), " Step4 analyzed cells are absent from RDS")
  counts <- counts[, idx, drop=FALSE]
  if (!identical(colnames(counts), meta$cell_id)) stop("Cell order reconciliation failed")

  feature_base <- clean_gene(rownames(counts))
  measured <- all_required[all_required %in% feature_base]
  cov <- data.table(gene=all_required, measured=all_required %in% feature_base, n_feature_rows=vapply(all_required, function(g) sum(feature_base==g), integer(1)))
  write_tsv(cov, "04B_01_selected_gene_coverage.tsv")
  logmsg("GENE_EXTRACT_START", "measured=", length(measured), "/", length(all_required))
  sel <- Matrix::Matrix(0, nrow=length(measured), ncol=ncol(counts), sparse=TRUE, dimnames=list(measured,colnames(counts)))
  for (i in seq_along(measured)) {
    ii <- which(feature_base==measured[i])
    if (length(ii)==1L) sel[i,] <- counts[ii,]
    else sel[i,] <- Matrix::colSums(counts[ii,,drop=FALSE])
  }
  logmsg("GENE_EXTRACT_DONE", "matrix=", nrow(sel), "x", ncol(sel))

  group_levels <- eligible$group_id
  gidx <- match(meta$group_id, group_levels)
  if (anyNA(gidx)) stop("Cell-to-eligible-group mapping failed")
  G <- sparseMatrix(i=seq_len(nrow(meta)), j=gidx, x=1, dims=c(nrow(meta),length(group_levels)), dimnames=list(meta$cell_id,group_levels))
  logmsg("PSEUDOBULK_START", "groups=", length(group_levels))
  PB <- sel %*% G
  LIB <- eligible$library_size
  names(LIB) <- eligible$group_id
  LIB <- LIB[colnames(PB)]
  if (anyNA(LIB)) stop("Saved Step4 library sizes failed to align")
  logcpm <- log2(t(t(as.matrix(PB))/pmax(as.numeric(LIB),1))*1e6+1)
  colnames(logcpm) <- colnames(PB)
  gene_z <- t(apply(logcpm,1,zsafe)); rownames(gene_z)<-rownames(logcpm); colnames(gene_z)<-colnames(logcpm)
  saveRDS(list(gene_z=gene_z, eligible=eligible, created=Sys.time(), object=obj_path), CACHE_FILE, compress=FALSE)
  logmsg("PSEUDOBULK_DONE", "cache_written=", CACHE_FILE)
  rm(obj, counts, sel, G, PB); invisible(gc())
}

version_rows <- function(program_name, version) {
  d <- programs[program == program_name]
  if (version=="host_causal_core") d <- d[score_set=="host_causal_core"]
  d[host_gene %in% rownames(gene_z)]
}
score_from_rows <- function(d, drop_genes=character()) {
  d <- d[!host_gene %in% clean_gene(drop_genes)]
  if (nrow(d)<MIN_GENES_PER_SCORE) return(NULL)
  genes <- d$host_gene; signs <- d$sign
  vals <- colMeans(sweep(gene_z[genes,,drop=FALSE],1,signs,`*`),na.rm=TRUE)
  out <- data.table(group_id=names(vals), score=as.numeric(vals))
  merge(out, eligible[,.(group_id,patient_id,broad_cell_type,cells,library_size)], by="group_id", all.x=TRUE)
}
paired_tam_tumor <- function(sc) {
  a <- sc[broad_cell_type==TAM_LABEL,.(patient_id,a=score)]
  b <- sc[broad_cell_type==TUMOR_LABEL,.(patient_id,b=score)]
  m <- merge(a,b,by="patient_id")
  if (nrow(m)<3L) return(list(n=nrow(m),median=NA_real_,mean=NA_real_,p=NA_real_))
  dif <- m$a-m$b
  wt <- suppressWarnings(wilcox.test(dif,mu=0,paired=FALSE,exact=FALSE))
  list(n=nrow(m),median=median(dif),mean=mean(dif),p=wt$p.value)
}
state_corr <- function(sc, sig_dt, compartment, program_genes) {
  groups <- sc[broad_cell_type==compartment,group_id]
  groups <- intersect(groups,colnames(gene_z))
  pdat <- sc[group_id %in% groups,.(group_id,patient_id,score)]
  out <- list()
  for (sig in unique(sig_dt$signature)) {
    req <- unique(sig_dt[signature==sig,gene])
    sgenes <- setdiff(intersect(req,rownames(gene_z)), program_genes)
    if (length(sgenes)<2L || nrow(pdat)<MIN_PATIENTS_FOR_CORRELATION) {
      out[[length(out)+1L]] <- data.table(signature=sig,n_patients=nrow(pdat),signature_genes=length(sgenes),overlap_removed=paste(intersect(req,program_genes),collapse=";"),rho=NA_real_,p_value=NA_real_)
    } else {
      cols <- match(pdat$group_id,colnames(gene_z))
      sval <- colMeans(gene_z[sgenes,cols,drop=FALSE],na.rm=TRUE)
      ct <- suppressWarnings(cor.test(pdat$score,sval,method="spearman",exact=FALSE))
      out[[length(out)+1L]] <- data.table(signature=sig,n_patients=nrow(pdat),signature_genes=length(sgenes),overlap_removed=paste(intersect(req,program_genes),collapse=";"),rho=unname(ct$estimate),p_value=ct$p.value)
    }
  }
  rbindlist(out,fill=TRUE)
}

# Reproduce original fixed scores before perturbation.
orig <- list()
for (pr in unique(programs$program)) for (sv in c("host_causal_core","expanded")) {
  d <- version_rows(pr,sv); sc <- score_from_rows(d)
  if (is.null(sc)) next
  sc[, `:=`(program=pr,score_version=sv)]
  orig[[length(orig)+1L]] <- sc
}
orig_scores <- rbindlist(orig,fill=TRUE)
old <- fread(STEP4_ORIGINAL_SCORES)[,.(group_id,program,score_version,old_score=program_score)]
rep_audit <- merge(orig_scores[,.(group_id,program,score_version,new_score=score)],old,by=c("group_id","program","score_version"))
rep_summary <- rep_audit[,.(n=.N,max_abs_difference=max(abs(new_score-old_score),na.rm=TRUE),mean_abs_difference=mean(abs(new_score-old_score),na.rm=TRUE)),by=.(program,score_version)]
write_tsv(rep_summary,"04B_02_step4_score_reproduction_audit.tsv")
logmsg("REPRODUCTION_AUDIT", "max_abs_diff=", signif(max(rep_summary$max_abs_difference),4))

# Original localization and gene-level signed effects.
original_con <- list(); gene_contrib <- list()
for (pr in unique(programs$program)) for (sv in c("host_causal_core","expanded")) {
  d <- version_rows(pr,sv); sc <- orig_scores[program==pr & score_version==sv]
  z <- paired_tam_tumor(sc)
  original_con[[length(original_con)+1L]] <- data.table(program=pr,score_version=sv,variant="original",genes_used=nrow(d),paired_patients=z$n,median_paired_difference=z$median,mean_paired_difference=z$mean,p_value=z$p)
  tam_groups <- eligible[broad_cell_type==TAM_LABEL,.(patient_id,tam_group=group_id)]
  tum_groups <- eligible[broad_cell_type==TUMOR_LABEL,.(patient_id,tum_group=group_id)]
  pp <- merge(tam_groups,tum_groups,by="patient_id")
  for (i in seq_len(nrow(d))) {
    g <- d$host_gene[i]; sg <- d$sign[i]
    dt <- gene_z[g,pp$tam_group]*sg - gene_z[g,pp$tum_group]*sg
    gene_contrib[[length(gene_contrib)+1L]] <- data.table(program=pr,score_version=sv,gene=g,sign=sg,paired_patients=nrow(pp),signed_mean_TAM_minus_Tumor=mean(dt),signed_median_TAM_minus_Tumor=median(dt),mean_program_effect_contribution=mean(dt)/nrow(d))
  }
}
original_con <- rbindlist(original_con); original_con[,FDR:=p.adjust(p_value,"BH")]
gene_contrib <- rbindlist(gene_contrib)
gene_contrib[, absolute_contribution_fraction := abs(mean_program_effect_contribution)/sum(abs(mean_program_effect_contribution)), by=.(program,score_version)]
write_tsv(original_con,"04B_03_original_localization_recomputed.tsv")
write_tsv(gene_contrib,"04B_04_gene_level_TAM_vs_Tumor_contributions.tsv")

# Leave-one-gene-out localization and Proinflammatory-TAM robustness.
loo_loc <- list(); loo_state <- list()
for (pr in unique(programs$program)) for (sv in c("host_causal_core","expanded")) {
  d0 <- version_rows(pr,sv)
  if (nrow(d0)<=MIN_GENES_PER_SCORE) next
  for (gdrop in d0$host_gene) {
    d <- d0[host_gene!=gdrop]
    sc <- score_from_rows(d)
    z <- paired_tam_tumor(sc)
    loo_loc[[length(loo_loc)+1L]] <- data.table(program=pr,score_version=sv,dropped_gene=gdrop,genes_remaining=nrow(d),paired_patients=z$n,median_paired_difference=z$median,mean_paired_difference=z$mean,p_value=z$p)
    tc <- state_corr(sc,tam_states,TAM_LABEL,d$host_gene)[signature=="Proinflammatory_TAM"]
    if (nrow(tc)) loo_state[[length(loo_state)+1L]] <- cbind(data.table(program=pr,score_version=sv,dropped_gene=gdrop,genes_remaining=nrow(d)),tc)
  }
}
loo_loc <- rbindlist(loo_loc,fill=TRUE); loo_loc[,FDR:=p.adjust(p_value,"BH")]
loo_state <- rbindlist(loo_state,fill=TRUE); loo_state[,FDR:=p.adjust(p_value,"BH")]
write_tsv(loo_loc,"04B_05_leave_one_gene_out_localization.tsv")
write_tsv(loo_state,"04B_06_leave_one_gene_out_Proinflammatory_TAM.tsv")

# LOO stability summary against the fixed original effect.
loo_sum <- merge(loo_loc,original_con[,.(program,score_version,original_median=median_paired_difference,original_mean=mean_paired_difference)],by=c("program","score_version"))
loo_summary <- loo_sum[,.(
  genes_in_original=.N,
  same_direction_fraction=mean(sign(median_paired_difference)==sign(original_median),na.rm=TRUE),
  median_abs_effect_retention=median(abs(median_paired_difference)/pmax(abs(original_median),1e-12),na.rm=TRUE),
  minimum_abs_effect_retention=min(abs(median_paired_difference)/pmax(abs(original_median),1e-12),na.rm=TRUE),
  max_abs_effect_retention=max(abs(median_paired_difference)/pmax(abs(original_median),1e-12),na.rm=TRUE),
  nominal_p_lt_0_05_fraction=mean(p_value<0.05,na.rm=TRUE),
  min_median_effect=min(median_paired_difference,na.rm=TRUE),max_median_effect=max(median_paired_difference,na.rm=TRUE)
),by=.(program,score_version,original_median,original_mean)]
write_tsv(loo_summary,"04B_07_leave_one_gene_out_stability_summary.tsv")
logmsg("LOO_DONE", "tests=", nrow(loo_loc))

# Predefined cytokine-depleted and broader immune-anchor-depleted scores.
dep_scores <- list(); dep_loc <- list(); dep_tam <- list(); dep_tum <- list(); dep_gene_audit <- list()
for (scheme_name in unique(depletion$scheme)) for (pr in unique(programs$program)) for (sv in c("host_causal_core","expanded")) {
  d0 <- version_rows(pr,sv)
  drops <- unique(depletion[scheme == scheme_name & program == pr, gene])
  drops <- intersect(drops,d0$host_gene)
  d <- d0[!host_gene %in% drops]
  dep_gene_audit[[length(dep_gene_audit)+1L]] <- data.table(scheme=scheme_name,program=pr,score_version=sv,genes_original=nrow(d0),genes_removed=length(drops),removed=paste(drops,collapse=";"),genes_remaining=nrow(d),remaining=paste(d$host_gene,collapse=";"))
  if (nrow(d)<MIN_GENES_PER_SCORE) next
  sc <- score_from_rows(d); sc[,`:=`(scheme=scheme_name,program=pr,score_version=sv,genes_remaining=nrow(d))]
  dep_scores[[length(dep_scores)+1L]] <- sc
  z <- paired_tam_tumor(sc)
  dep_loc[[length(dep_loc)+1L]] <- data.table(scheme=scheme_name,program=pr,score_version=sv,genes_remaining=nrow(d),paired_patients=z$n,median_paired_difference=z$median,mean_paired_difference=z$mean,p_value=z$p)
  tc <- state_corr(sc,tam_states,TAM_LABEL,d$host_gene); tc[,`:=`(scheme=scheme_name,program=pr,score_version=sv,genes_remaining=nrow(d))]
  dep_tam[[length(dep_tam)+1L]] <- tc
  uc <- state_corr(sc,tumor_states,TUMOR_LABEL,d$host_gene); uc[,`:=`(scheme=scheme_name,program=pr,score_version=sv,genes_remaining=nrow(d))]
  dep_tum[[length(dep_tum)+1L]] <- uc
}
dep_gene_audit <- rbindlist(dep_gene_audit,fill=TRUE)
dep_scores <- rbindlist(dep_scores,fill=TRUE)
dep_loc <- rbindlist(dep_loc,fill=TRUE); dep_loc[,FDR:=p.adjust(p_value,"BH")]
dep_tam <- rbindlist(dep_tam,fill=TRUE); dep_tam[,FDR:=p.adjust(p_value,"BH")]
dep_tum <- rbindlist(dep_tum,fill=TRUE); dep_tum[,FDR:=p.adjust(p_value,"BH")]
write_tsv(dep_gene_audit,"04B_08_depletion_gene_set_audit.tsv")
write_tsv(dep_scores,"04B_09_depleted_patient_celltype_scores.tsv")
write_tsv(dep_loc,"04B_10_depleted_TAM_vs_Tumor_localization.tsv")
write_tsv(dep_tam,"04B_11_depleted_TAM_state_correlations.tsv")
write_tsv(dep_tum,"04B_12_depleted_tumor_Neftel_correlations.tsv")
logmsg("DEPLETION_DONE", "localization_tests=", nrow(dep_loc), "; TAM_state_tests=", nrow(dep_tam))

# Compact carry-forward table. No result-dependent gene reselection is performed.
carry <- merge(original_con[,.(program,score_version,original_median=median_paired_difference,original_FDR=FDR)],loo_summary[,.(program,score_version,same_direction_fraction,median_abs_effect_retention,minimum_abs_effect_retention)],by=c("program","score_version"),all=TRUE)
cyt <- dep_loc[scheme=="cytokine_depleted",.(program,score_version,cytokine_depleted_median=median_paired_difference,cytokine_depleted_FDR=FDR,cytokine_genes_remaining=genes_remaining)]
imm <- dep_loc[scheme=="immune_anchor_depleted",.(program,score_version,immune_anchor_depleted_median=median_paired_difference,immune_anchor_depleted_FDR=FDR,immune_anchor_genes_remaining=genes_remaining)]
carry <- merge(carry,cyt,by=c("program","score_version"),all=TRUE); carry <- merge(carry,imm,by=c("program","score_version"),all=TRUE)
carry[, `:=`(
  LOO_direction_stable = same_direction_fraction==1,
  cytokine_direction_preserved = sign(cytokine_depleted_median)==sign(original_median),
  immune_anchor_direction_preserved = sign(immune_anchor_depleted_median)==sign(original_median)
)]
write_tsv(carry,"04B_13_robustness_carry_forward.tsv")

manifest <- data.table(
  item=c("object","step4_metadata","step4_eligible_groups","program_definition","depletion_definition","cache","inferential_unit","purpose"),
  value=c(if (exists("obj_path")) obj_path else "loaded_from_cache", STEP4_META, STEP4_ELIGIBLE, PROGRAM_FILE, DEPLETION_FILE, CACHE_FILE, "patient x broad-cell-type pseudobulk", "robustness only; fixed Step4 programs are not reselected")
)
write_tsv(manifest,"04B_14_analysis_manifest.tsv")
writeLines(capture.output(sessionInfo()),file.path(TABLE_DIR,"sessionInfo.txt"))
logmsg("COMPLETE", "Step4B robustness analysis complete")
