# Step 4B — GSE182109 lineage-robustness analysis

This is a **sensitivity analysis only**. It does not replace or reselect the four fixed Step 4 programs.

## Questions
1. Is TAM-vs-Tumor localization driven by one single program gene?
2. Does localization persist after removing prespecified inflammatory cytokine/chemokine genes?
3. Does it persist after a broader depletion of immune/myeloid anchors?
4. Do IPA/Succinate/TMAO associations with the Proinflammatory-TAM state persist under those perturbations?

## Prespecified tests
- Leave-one-gene-out (LOO), core and expanded scores.
- Cytokine-depleted score.
- Immune-anchor-depleted score.
- Gene-level signed contribution audit.
- Patient-level paired TAM-vs-Tumor tests.
- Overlap-removed TAM-state correlations.
- Tumor Neftel correlations under depletion are provided as a secondary sensitivity analysis.

The removal sets are stored in `resources/04B_predefined_depletion_sets.tsv`. They are fixed before running Step 4B and are not selected from Step 4B p-values.

## Runtime note
The first run must deserialize the large GSE182109 Seurat RDS again and can therefore spend hours at `READ_RDS_START`. Detailed phase logging is provided. After the first successful extraction, a small uncompressed cache is written to:

`/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04B_singlecell_robustness/cache/04B_selected_gene_patient_celltype_cache.rds`

Subsequent reruns skip the large RDS and should be much faster.

## Run
From the uploaded, already-unzipped package directory:

`nohup Rscript scripts/09_run_all.R > step4B_console.log 2>&1 &`

## Main outputs
- `04B_02_step4_score_reproduction_audit.tsv`
- `04B_04_gene_level_TAM_vs_Tumor_contributions.tsv`
- `04B_05_leave_one_gene_out_localization.tsv`
- `04B_07_leave_one_gene_out_stability_summary.tsv`
- `04B_10_depleted_TAM_vs_Tumor_localization.tsv`
- `04B_11_depleted_TAM_state_correlations.tsv`
- `04B_12_depleted_tumor_Neftel_correlations.tsv`
- `04B_13_robustness_carry_forward.tsv`

## v2 path-resolution fix
`09_run_all.R` now resolves its own absolute path before sourcing any child scripts and sources with `chdir = FALSE`. This prevents the former `normalizePath("scripts/..")` failure when the runner is launched as `Rscript scripts/09_run_all.R` from the package root.
