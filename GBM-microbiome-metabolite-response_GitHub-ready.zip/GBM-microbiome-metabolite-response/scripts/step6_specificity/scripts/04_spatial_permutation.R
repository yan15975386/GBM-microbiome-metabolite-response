source(file.path(PACKAGE_DIR,"scripts","00_utils.R"),local=FALSE)
set.seed(RANDOM_SEED+17L)
hyp <- fread(HYPOTHESIS_FILE)
cache <- pick_file(STEP5_ROOT,"05_scored_spots_cache\\.rds$")
if (!file.exists(cache)) stop("Step 5 scored-spots cache not found.")
x <- readRDS(cache)
scores <- as.data.table(x$scores)
programs <- x$programs; programs[,gene:=toupper(gene)]
contexts <- x$contexts; contexts[,gene:=toupper(gene)]
Z <- x$Z; rownames(Z) <- toupper(rownames(Z))

rankz <- function(v) {
  r <- rank(v,ties.method="average",na.last="keep")
  ok <- is.finite(r)
  rr <- rep(NA_real_,length(r))
  if (sum(ok)>2) rr[ok] <- (r[ok]-mean(r[ok]))/sd(r[ok])
  rr
}

res <- list()
for (i in seq_len(nrow(hyp))) {
  pr <- hyp$program[i]; sg <- hyp$context[i]; edir <- hyp$expected_direction[i]
  pc <- paste(pr,"causal_core",sep="__")
  if (!pc %in% names(scores)) stop("Missing program score: ",pc)
  pg <- programs[program==pr & score_version=="causal_core"]$gene
  cg <- intersect(setdiff(contexts[signature==sg]$gene,pg),rownames(Z))
  if (!length(cg)) stop("No overlap-removed context genes for ",pr," / ",sg)

  slide_obs <- list()
  # store null slide estimates in long matrix rows=slides, cols=permutations
  slides <- unique(scores$slide)
  nullmat <- matrix(NA_real_,nrow=length(slides),ncol=N_SPATIAL_PERM,dimnames=list(slides,NULL))
  pats <- character(length(slides))
  for (j in seq_along(slides)) {
    sl <- slides[j]
    idx <- which(scores$slide==sl)
    pats[j] <- as.character(unique(scores$patient[idx])[1])
    pv <- scores[[pc]][idx]
    cv <- colMeans(Z[cg,idx,drop=FALSE],na.rm=TRUE)
    rx <- rankz(pv); ry <- rankz(cv)
    ok <- is.finite(rx) & is.finite(ry)
    rx <- rx[ok]; ry <- ry[ok]
    obs <- sum(rx*ry)/(length(rx)-1)
    slide_obs[[j]] <- data.table(slide=sl,patient=pats[j],rho=obs)
    n <- length(ry)
    for (b in seq_len(N_SPATIAL_PERM)) {
      nullmat[j,b] <- sum(rx*ry[sample.int(n,n,replace=FALSE)])/(n-1)
    }
  }
  sobs <- rbindlist(slide_obs)
  pobs <- sobs[,.(rho=median(rho,na.rm=TRUE)),by=patient]
  observed_global <- median(pobs$rho,na.rm=TRUE)

  null_global <- numeric(N_SPATIAL_PERM)
  for (b in seq_len(N_SPATIAL_PERM)) {
    tmp <- data.table(patient=pats,rho=nullmat[,b])
    pp <- tmp[,.(rho=median(rho,na.rm=TRUE)),by=patient]
    null_global[b] <- median(pp$rho,na.rm=TRUE)
  }
  ep <- empirical_one_sided(observed_global,null_global,edir)
  res[[i]] <- data.table(program=pr,context=sg,expected_direction=edir,n_patients=nrow(pobs),observed_median_patient_rho=observed_global,null_median=median(null_global),null_q025=quantile(null_global,.025),null_q975=quantile(null_global,.975),empirical_p=ep)
  fwrite(data.table(iter=seq_len(N_SPATIAL_PERM),median_patient_rho=null_global),file.path(CACHE_DIR,sprintf("06C_spatial_null_%s_%s.tsv.gz",pr,sg)),sep="\t",compress="gzip")
}
out <- rbindlist(res)
out[,empirical_FDR:=bh(empirical_p)]
write_tsv(out,file.path(TABLE_DIR,"06C_spatial_permutation_empirical_tests.tsv"))
log_msg("SPATIAL_NULL_DONE","Completed",nrow(out),"within-slide permutation tests.")
