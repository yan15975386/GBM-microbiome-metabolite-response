PROJECT_ROOT <- "/media/desk16/iy12923/GBM_new/gut"
OUT_ROOT <- file.path(PROJECT_ROOT,"gutGBM_microbiome_metabolite_rebuild","06_integration_specificity_v2_fixed")
TABLE_DIR <- file.path(OUT_ROOT,"tables")
FIG_DIR <- file.path(OUT_ROOT,"figures")
CACHE_DIR <- file.path(OUT_ROOT,"cache")
LOG_DIR <- file.path(OUT_ROOT,"logs")
dir.create(TABLE_DIR,recursive=TRUE,showWarnings=FALSE)
dir.create(FIG_DIR,recursive=TRUE,showWarnings=FALSE)
dir.create(CACHE_DIR,recursive=TRUE,showWarnings=FALSE)
dir.create(LOG_DIR,recursive=TRUE,showWarnings=FALSE)
LOG_FILE <- file.path(LOG_DIR,"Step6_integration.log")

STEP3_ROOT <- file.path(PROJECT_ROOT,"gutGBM_microbiome_metabolite_rebuild","03_bulkRNA")
STEP4_ROOT <- file.path(PROJECT_ROOT,"gutGBM_microbiome_metabolite_rebuild","04_singlecell")
STEP4B_ROOT <- file.path(PROJECT_ROOT,"gutGBM_microbiome_metabolite_rebuild","04B_singlecell_robustness")
STEP5_ROOT <- file.path(PROJECT_ROOT,"gutGBM_microbiome_metabolite_rebuild","05_spatial_v3_fixed")

TCGA_EXPR <- "/media/desk16/iy12923/GBM_new/source/TCGA/tcga539_exp_unlog.xlsx"

N_RANDOM <- 1000L
N_SPATIAL_PERM <- 500L
N_EXPR_BINS <- 20L
RANDOM_SEED <- 260903L

PROGRAM_FILE <- file.path(PACKAGE_DIR,"config","01_programs.tsv")
CONTEXT_FILE <- file.path(PACKAGE_DIR,"config","02_context_signatures.tsv")
HYPOTHESIS_FILE <- file.path(PACKAGE_DIR,"config","03_primary_hypotheses.tsv")
UPSTREAM_FILE <- file.path(PACKAGE_DIR,"config","04_upstream_evidence.tsv")
