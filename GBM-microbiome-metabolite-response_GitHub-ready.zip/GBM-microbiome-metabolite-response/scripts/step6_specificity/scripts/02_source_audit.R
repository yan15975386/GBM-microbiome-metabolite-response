source(file.path(PACKAGE_DIR,"scripts","00_utils.R"),local=FALSE)

needed <- data.table(
 layer=c("Step3_bulk","Step4_singlecell","Step4B_robustness","Step5_spatial",
         "Step3_bulk_context","Step4_paired","Step4B_LOO","Step4B_depletion",
         "Step5_same_spot","Step5_neighborhood","Step5_spatial_cache"),
 root=c(STEP3_ROOT,STEP4_ROOT,STEP4B_ROOT,STEP5_ROOT,
        STEP3_ROOT,STEP4_ROOT,STEP4B_ROOT,STEP4B_ROOT,
        STEP5_ROOT,STEP5_ROOT,STEP5_ROOT),
 pattern=c("","", "", "",
           "03F.*overlap.*context.*\\.tsv$",
           "04F.*paired.*localization.*\\.tsv$",
           "04B_07.*stability.*summary.*\\.tsv$",
           "04B_10.*depleted.*TAM.*Tumor.*\\.tsv$",
           "05G_patient_same_spot_tests\\.tsv$",
           "05J_patient_neighborhood_tests\\.tsv$",
           "05_scored_spots_cache\\.rds$")
)
needed[, exists_root := dir.exists(root)]
needed[, selected_file := ifelse(pattern=="",root,mapply(function(r,p) pick_file(r,p),root,pattern))]
needed[, exists_file := ifelse(pattern=="",dir.exists(selected_file),file.exists(selected_file))]
write_tsv(needed,file.path(TABLE_DIR,"06A_source_file_audit.tsv"))
log_msg("SOURCE_AUDIT","Source audit written.")
