suppressPackageStartupMessages({library(data.table);library(ggplot2)})
source(file.path(PACKAGE_DIR,"scripts","00_utils.R"),local=FALSE)

d <- fread(file.path(TABLE_DIR,"06D_cross_modal_direction_concordance.tsv"))
e <- fread(file.path(TABLE_DIR,"06E_axis_evidence_matrix.tsv"))
bn <- fread(file.path(TABLE_DIR,"06B_TCGA_matched_random_empirical_tests.tsv"))
sp <- fread(file.path(TABLE_DIR,"06C_spatial_permutation_empirical_tests.tsv"))

# Figure 6A: evidence-direction map
dd <- rbind(
  d[,.(program,context,layer="Spatial same spot",value=spatial_same_spot_rho)],
  d[,.(program,context,layer="Spatial neighborhood",value=spatial_neighbor_rho)]
)
p1 <- ggplot(dd,aes(x=context,y=program,fill=value))+geom_tile()+geom_text(aes(label=sprintf("%.2f",value)),size=3)+facet_wrap(~layer)+scale_fill_gradient2(midpoint=0)+theme_minimal(base_size=9)+labs(x=NULL,y=NULL,fill="rho",title="Cross-modal spatial direction map")
ggsave(file.path(FIG_DIR,"Figure6A_cross_modal_evidence_map.png"),p1,width=9,height=4.5,dpi=300)
ggsave(file.path(FIG_DIR,"Figure6A_cross_modal_evidence_map.pdf"),p1,width=9,height=4.5)

# Figure 6B: TCGA matched-random empirical specificity
bn[,label:=paste(program,context,sep=" — ")]
p2 <- ggplot(bn,aes(x=reorder(label,-log10(empirical_p)),y=-log10(empirical_p)))+geom_col()+geom_hline(yintercept=-log10(.05),lty=2)+coord_flip()+theme_minimal(base_size=9)+labs(x=NULL,y="-log10 empirical p",title="TCGA expression-matched random-program specificity")
ggsave(file.path(FIG_DIR,"Figure6B_TCGA_matched_random_specificity.png"),p2,width=7,height=5.5,dpi=300)
ggsave(file.path(FIG_DIR,"Figure6B_TCGA_matched_random_specificity.pdf"),p2,width=7,height=5.5)

# Figure 6C: spatial permutation
sp[,label:=paste(program,context,sep=" — ")]
p3 <- ggplot(sp,aes(x=reorder(label,-log10(empirical_p)),y=-log10(empirical_p)))+geom_col()+geom_hline(yintercept=-log10(.05),lty=2)+coord_flip()+theme_minimal(base_size=9)+labs(x=NULL,y="-log10 empirical p",title="Within-slide spatial permutation specificity")
ggsave(file.path(FIG_DIR,"Figure6C_spatial_permutation_specificity.png"),p3,width=7,height=5.5,dpi=300)
ggsave(file.path(FIG_DIR,"Figure6C_spatial_permutation_specificity.pdf"),p3,width=7,height=5.5)

# Figure 6D: final rule-based classification
plotd <- e[,.(program,bulk_direction_match_fraction,spatial_same_spot_direction_match_fraction,spatial_neighbor_direction_match_fraction)]
long <- melt(plotd,id.vars="program",variable.name="evidence",value.name="fraction")
p4 <- ggplot(long,aes(x=evidence,y=program,fill=fraction))+geom_tile()+geom_text(aes(label=ifelse(is.finite(fraction),sprintf("%.2f",fraction),"NA")),size=3)+scale_fill_gradient(limits=c(0,1))+theme_minimal(base_size=9)+theme(axis.text.x=element_text(angle=30,hjust=1))+labs(x=NULL,y=NULL,fill="Directional concordance",title="Rule-based cross-modal axis summary")
ggsave(file.path(FIG_DIR,"Figure6D_final_axis_summary.png"),p4,width=8,height=4.5,dpi=300)
ggsave(file.path(FIG_DIR,"Figure6D_final_axis_summary.pdf"),p4,width=8,height=4.5)

log_msg("FIGURES_DONE","Step 6 figures generated.")
