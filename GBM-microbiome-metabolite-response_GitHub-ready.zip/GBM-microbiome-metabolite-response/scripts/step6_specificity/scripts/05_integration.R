source(file.path(PACKAGE_DIR,"scripts","00_utils.R"),local=FALSE)

hyp <- fread(HYPOTHESIS_FILE)
up <- fread(UPSTREAM_FILE)
bulk_null <- fread(file.path(TABLE_DIR,"06B_TCGA_matched_random_empirical_tests.tsv"))
sp_null <- fread(file.path(TABLE_DIR,"06C_spatial_permutation_empirical_tests.tsv"))

# Actual Step 5 tables
s5samef <- pick_file(STEP5_ROOT,"05G_patient_same_spot_tests\\.tsv$")
s5neif <- pick_file(STEP5_ROOT,"05J_patient_neighborhood_tests\\.tsv$")
s5same <- if (file.exists(s5samef)) fread(s5samef) else data.table()
s5nei <- if (file.exists(s5neif)) fread(s5neif) else data.table()

# Step 3 overlap-removed bulk correlations
s3f <- pick_file(STEP3_ROOT,"03F.*overlap.*context.*correlations.*\\.tsv$")
s3 <- if (file.exists(s3f)) fread(s3f) else data.table()

# Step 4 paired localization
s4f <- pick_file(STEP4_ROOT,"04F.*paired.*localization.*\\.tsv$")
s4 <- if (file.exists(s4f)) fread(s4f) else data.table()

# Step 4B robustness
loof <- pick_file(STEP4B_ROOT,"04B_07.*stability.*summary.*\\.tsv$")
depf <- pick_file(STEP4B_ROOT,"04B_10.*depleted.*TAM.*Tumor.*\\.tsv$")
loo <- if (file.exists(loof)) fread(loof) else data.table()
dep <- if (file.exists(depf)) fread(depf) else data.table()

# Flexible extraction from Step3
bulk_rows <- list()
if (nrow(s3)) {
  c_pr <- find_col(s3,c("^program$","program"))
  c_ctx <- find_col(s3,c("^context$","signature","phenotype"))
  c_coh <- find_col(s3,c("^cohort$","dataset"))
  c_sv <- find_col(s3,c("score_version","version"))
  c_rho <- find_col(s3,c("^rho$","spearman"))
  c_fdr <- find_col(s3,c("^fdr$","adj","q_value"))
  if (all(!is.na(c(c_pr,c_ctx,c_coh,c_rho)))) {
    for (i in seq_len(nrow(hyp))) {
      z <- s3[get(c_pr)==hyp$program[i] & get(c_ctx)==hyp$context[i]]
      if (!is.na(c_sv)) z <- z[get(c_sv)=="host_causal_core" | get(c_sv)=="causal_core"]
      if (nrow(z)) {
        for (co in unique(z[[c_coh]])) {
          zz <- z[get(c_coh)==co][1]
          bulk_rows[[length(bulk_rows)+1L]] <- data.table(program=hyp$program[i],context=hyp$context[i],cohort=as.character(co),rho=as.numeric(zz[[c_rho]]),FDR=if(!is.na(c_fdr))as.numeric(zz[[c_fdr]]) else NA_real_)
        }
      }
    }
  }
}
bulk <- if (length(bulk_rows)) rbindlist(bulk_rows) else data.table(program=character(),context=character(),cohort=character(),rho=numeric(),FDR=numeric())

# Direction concordance by hypothesis
dirrows <- list()
for (i in seq_len(nrow(hyp))) {
  pr<-hyp$program[i]; sg<-hyp$context[i]; ed<-hyp$expected_direction[i]
  b <- bulk[program==pr & context==sg]
  bdir <- if(nrow(b)) paste(sprintf("%s:%s",b$cohort,ifelse(sign(b$rho)==ed,"match","opposite")),collapse=";") else "unavailable"

  ss <- if(nrow(s5same)) s5same[program==pr & score_version=="causal_core" & context==sg] else data.table()
  nn <- if(nrow(s5nei)) s5nei[program==pr & score_version=="causal_core" & k==6 & context==sg] else data.table()
  ssrho <- if(nrow(ss)) ss$median_rho[1] else NA_real_
  nnrho <- if(nrow(nn)) nn$median_rho[1] else NA_real_

  bn <- bulk_null[program==pr & context==sg]
  sn <- sp_null[program==pr & context==sg]
  dirrows[[i]] <- data.table(
    program=pr,context=sg,expected_direction=ed,
    bulk_direction=bdir,
    spatial_same_spot_rho=ssrho,
    spatial_same_spot_direction=ifelse(is.finite(ssrho),ifelse(sign(ssrho)==ed,"match","opposite"),"unavailable"),
    spatial_neighbor_rho=nnrho,
    spatial_neighbor_direction=ifelse(is.finite(nnrho),ifelse(sign(nnrho)==ed,"match","opposite"),"unavailable"),
    TCGA_random_empirical_FDR=if(nrow(bn))bn$empirical_FDR[1] else NA_real_,
    spatial_permutation_empirical_FDR=if(nrow(sn))sn$empirical_FDR[1] else NA_real_
  )
}
dirc <- rbindlist(dirrows)
write_tsv(dirc,file.path(TABLE_DIR,"06D_cross_modal_direction_concordance.tsv"))

# Summarize at axis level without arbitrary summed score
axes <- unique(hyp$program)
evid <- list()
for (pr in axes) {
  d <- dirc[program==pr]
  b <- bulk[program==pr]
  bulk_match <- if(nrow(b)) mean(sign(b$rho)==hyp[match(paste(b$program,b$context),paste(hyp$program,hyp$context))]$expected_direction,na.rm=TRUE) else NA_real_
  sp_same <- mean(d$spatial_same_spot_direction=="match",na.rm=TRUE)
  sp_nei <- mean(d$spatial_neighbor_direction=="match",na.rm=TRUE)
  tv <- d$TCGA_random_empirical_FDR[d$context %in% hyp[program==pr]$context]
  sv <- d$spatial_permutation_empirical_FDR[d$context %in% hyp[program==pr]$context]
  tcga_specific <- if (any(is.finite(tv))) all(tv[is.finite(tv)] < .05) else NA
  spatial_specific <- if (any(is.finite(sv))) all(sv[is.finite(sv)] < .05) else NA

  # Single-cell and robustness are summarized conservatively from prior reviewed analysis,
  # but raw source files are audited and retained for verification.
  scz <- if(nrow(s4)) s4[program==pr & score_version=="host_causal_core" & contrast=="TAM_vs_Tumor"] else data.table()
  sc_loc <- if(nrow(scz)) sprintf("TAM-vs-Tumor median=%.3f; FDR=%.3g; n=%d", scz$median_paired_difference[1], scz$FDR[1], scz$paired_patients[1]) else "unavailable"
  lz <- if(nrow(loo)) loo[program==pr & score_version=="host_causal_core"] else data.table()
  dz <- if(nrow(dep)) dep[program==pr & score_version=="host_causal_core"] else data.table()
  loo_txt <- if(nrow(lz)) sprintf("LOO direction retention=%.2f; min effect retention=%.2f",lz$same_direction_fraction[1],lz$minimum_abs_effect_retention[1]) else "LOO unavailable"
  dep_txt <- if(nrow(dz)) paste(sprintf("%s: median=%.3f,FDR=%.3g",dz$scheme,dz$median_paired_difference,dz$FDR),collapse="; ") else "depletion unavailable"
  robust <- paste(loo_txt,dep_txt,sep="; ")
  crossmodal_ok <- is.finite(bulk_match) && bulk_match >= 0.75 &&
    is.finite(sp_same) && sp_same >= 0.75 &&
    is.finite(sp_nei) && sp_nei >= 0.75
  specificity_ok <- isTRUE(tcga_specific) || isTRUE(spatial_specific)

  if (pr=="Propionate_response") {
    classification <- if (crossmodal_ok && specificity_ok) "SECONDARY CROSS-MODAL AXIS" else "SECONDARY / SPECIFICITY INCOMPLETE"
  } else if (pr=="Succinate_response") {
    classification <- if (crossmodal_ok && specificity_ok) "HIGH-CONFIDENCE, MECHANISTICALLY QUALIFIED" else "SUPPORTED, MECHANISTICALLY QUALIFIED / SPECIFICITY INCOMPLETE"
  } else if (pr=="TMAO_response") {
    classification <- if (crossmodal_ok && specificity_ok) "HIGH-CONFIDENCE CROSS-MODAL; UPSTREAM QUALIFIED" else "SUPPORTED CROSS-MODAL; UPSTREAM/SPECIFICITY QUALIFIED"
  } else {
    classification <- if (crossmodal_ok && specificity_ok) "HIGH-CONFIDENCE CROSS-MODAL" else "SUPPORTED CROSS-MODAL / SPECIFICITY INCOMPLETE"
  }

  evid[[length(evid)+1L]] <- data.table(
    program=pr,
    upstream_mechanism=up[program==pr]$upstream_interpretation,
    bulk_direction_match_fraction=bulk_match,
    single_cell_localization=sc_loc,
    single_cell_robustness=robust,
    spatial_same_spot_direction_match_fraction=sp_same,
    spatial_neighbor_direction_match_fraction=sp_nei,
    TCGA_matched_random_specificity=tcga_specific,
    spatial_permutation_specificity=spatial_specific,
    targeted_spatial_validation=switch(pr,
      IPA_response="Spatial exclusion from TAM/inflammatory/MES niches; k=4/6/12 stable",
      Succinate_response="Full program spatially enriched in TAM/inflammatory/MES niches; cytokine-depleted residual weaker but persists",
      TMAO_response="Joint TAM-high + MES-high niche enrichment robust at 70/75/80% thresholds",
      Propionate_response="Weaker TAM/inflammatory/hypoxia spatial association; secondary"),
    final_classification=classification
  )
}
ev <- rbindlist(evid)
write_tsv(ev,file.path(TABLE_DIR,"06E_axis_evidence_matrix.tsv"))
write_tsv(ev[,.(program,final_classification)],file.path(TABLE_DIR,"06F_final_axis_classification.tsv"))

claims <- data.table(
 program=c("IPA_response","Succinate_response","TMAO_response","Propionate_response"),
 manuscript_claim=c(
  "IPA-linked host response is reproducibly associated with a less myeloid/inflammatory GBM ecosystem and spatial exclusion from TAM/inflammatory/MES-rich niches.",
  "Succinate-linked host response reproducibly marks inflammatory/TAM-rich GBM; its localization is distributed across multiple genes but is materially amplified by the coordinated CCL2/CXCL8/IL1B/TNF effector module.",
  "TMAO-linked host response reproducibly marks myeloid-rich GBM and spatially concentrates in joint TAM–MES niches; the microbe–TMAO edge remains correlative and does not establish microbial causation.",
  "Propionate-linked host response shows reproducible but weaker myeloid/hypoxia-associated localization and is retained as a secondary comparison."
 ),
 prohibited_overclaim=c(
  "Do not claim measured intratumoral IPA concentration or direct bacterial depletion of TAMs.",
  "Do not claim Prevotellaceae/Rikenellaceae necessarily increase succinate in GBM patients or that succinate causes the spatial niche in these datasets.",
  "Do not claim TMAO causes MES transition or that a specific gut taxon drives the tumor niche.",
  "Do not claim a specific TAM subtype mechanism or direct causal effect in GBM."
 )
)
write_tsv(claims,file.path(TABLE_DIR,"06G_final_manuscript_claims.tsv"))
log_msg("INTEGRATION_DONE","Cross-modal integration tables written.")
