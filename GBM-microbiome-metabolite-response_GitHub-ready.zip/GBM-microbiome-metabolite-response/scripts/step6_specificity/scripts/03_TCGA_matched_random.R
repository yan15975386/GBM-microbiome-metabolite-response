source(file.path(PACKAGE_DIR,"scripts","00_utils.R"),local=FALSE)
suppressPackageStartupMessages(library(readxl))

set.seed(RANDOM_SEED)
programs <- fread(PROGRAM_FILE); programs[,gene:=toupper(gene)]
contexts <- fread(CONTEXT_FILE); contexts[,gene:=toupper(gene)]
hyp <- fread(HYPOTHESIS_FILE)

log_msg("TCGA_NULL","Reading TCGA expression:",TCGA_EXPR)
dt <- as.data.table(read_excel(TCGA_EXPR))
gene_col <- if ("GeneSymbol" %in% names(dt)) "GeneSymbol" else names(dt)[1]
scols <- grep("^TCGA-",names(dt),value=TRUE)
if (length(scols)<100) stop("Could not identify TCGA sample columns.")
genes <- toupper(trimws(as.character(dt[[gene_col]])))
mat <- as.matrix(dt[,..scols]); storage.mode(mat) <- "numeric"
rownames(mat) <- genes
keep <- nzchar(genes) & !is.na(genes)
mat <- mat[keep,,drop=FALSE]
# collapse duplicate genes by mean
if (anyDuplicated(rownames(mat))) {
  u <- unique(rownames(mat))
  m2 <- matrix(NA_real_,nrow=length(u),ncol=ncol(mat),dimnames=list(u,colnames(mat)))
  for (i in seq_along(u)) m2[i,] <- colMeans(mat[rownames(mat)==u[i],,drop=FALSE],na.rm=TRUE)
  mat <- m2
}
q99 <- suppressWarnings(quantile(mat[is.finite(mat)],.99,na.rm=TRUE))
if (is.finite(q99) && q99>50) mat <- log2(mat+1)
Z <- z_rows(mat)
mean_expr <- rowMeans(mat,na.rm=TRUE)

# expression bins
valid <- is.finite(mean_expr)
breaks <- unique(quantile(mean_expr[valid],probs=seq(0,1,length.out=N_EXPR_BINS+1),na.rm=TRUE))
expr_bin <- cut(mean_expr,breaks=breaks,include.lowest=TRUE,labels=FALSE)
names(expr_bin) <- rownames(mat)

all_real_program <- unique(programs$gene)
all_context <- unique(contexts$gene)
eligible <- setdiff(rownames(mat),union(all_real_program,all_context))
eligible <- eligible[is.finite(expr_bin[eligible])]

sample_matched <- function(obs_genes) {
  chosen <- character()
  for (g in obs_genes) {
    b <- expr_bin[g]
    pool <- eligible[expr_bin[eligible]==b]
    pool <- setdiff(pool,chosen)
    if (!length(pool)) {
      near <- eligible[abs(expr_bin[eligible]-b)<=1]
      pool <- setdiff(near,chosen)
    }
    if (!length(pool)) stop("No matched random gene available for ",g)
    chosen <- c(chosen,sample(pool,1))
  }
  chosen
}

observed <- list(); null_rows <- list(); tests <- list()
for (i in seq_len(nrow(hyp))) {
  pr <- hyp$program[i]; sg <- hyp$context[i]; edir <- hyp$expected_direction[i]
  def <- programs[program==pr & score_version=="causal_core" & gene %in% rownames(Z)]
  cg <- contexts[signature==sg]$gene
  cg2 <- setdiff(cg,def$gene)
  cv <- context_score(Z,cg2)
  ov <- score_signed(Z,def$gene,def$direction)
  obs <- safe_cor(ov,cv)
  null <- numeric(N_RANDOM)
  for (b in seq_len(N_RANDOM)) {
    rg <- sample_matched(def$gene)
    rv <- score_signed(Z,rg,def$direction)
    null[b] <- safe_cor(rv,cv)
  }
  pemp <- empirical_one_sided(obs,null,edir)
  observed[[i]] <- data.table(program=pr,context=sg,expected_direction=edir,n_program_genes=nrow(def),observed_rho=obs)
  null_rows[[i]] <- data.table(program=pr,context=sg,expected_direction=edir,n_random=N_RANDOM,null_median=median(null,na.rm=TRUE),null_q025=quantile(null,.025,na.rm=TRUE),null_q975=quantile(null,.975,na.rm=TRUE),null_mean=mean(null,na.rm=TRUE),null_sd=sd(null,na.rm=TRUE))
  tests[[i]] <- data.table(program=pr,context=sg,expected_direction=edir,observed_rho=obs,empirical_p=pemp,random_percentile=mean(null<=obs,na.rm=TRUE))
  fwrite(data.table(iter=seq_len(N_RANDOM),rho=null),file.path(CACHE_DIR,sprintf("06B_null_%s_%s.tsv.gz",pr,sg)),sep="\t",compress="gzip")
}
obsdt <- rbindlist(observed); nulldt <- rbindlist(null_rows); testdt <- rbindlist(tests)
testdt[,empirical_FDR:=bh(empirical_p)]
write_tsv(obsdt,file.path(TABLE_DIR,"06B_TCGA_matched_random_observed.tsv"))
write_tsv(nulldt,file.path(TABLE_DIR,"06B_TCGA_matched_random_null_summary.tsv"))
write_tsv(testdt,file.path(TABLE_DIR,"06B_TCGA_matched_random_empirical_tests.tsv"))
saveRDS(list(mean_expr=mean_expr,expr_bin=expr_bin),file.path(CACHE_DIR,"06B_TCGA_expression_matching_cache.rds"))
log_msg("TCGA_NULL_DONE","Completed",nrow(hyp),"hypothesis-specific matched-random tests.")
