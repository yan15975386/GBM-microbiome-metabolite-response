args <- commandArgs(trailingOnly=FALSE)
fa <- sub("^--file=","",args[grep("^--file=",args)][1])
PACKAGE_DIR <- normalizePath(file.path(dirname(fa),".."),mustWork=TRUE)
source(file.path(PACKAGE_DIR,"scripts","01_config.R"),local=FALSE)
source(file.path(PACKAGE_DIR,"scripts","00_utils.R"),local=FALSE)

log_msg("START","Step 6 cross-modal integration and specificity validation")
log_msg("PACKAGE",PACKAGE_DIR)
log_msg("PARAMETERS",paste0("N_RANDOM=",N_RANDOM,"; N_SPATIAL_PERM=",N_SPATIAL_PERM,"; bins=",N_EXPR_BINS))

source(file.path(PACKAGE_DIR,"scripts","02_source_audit.R"),local=FALSE)
source(file.path(PACKAGE_DIR,"scripts","03_TCGA_matched_random.R"),local=FALSE)
source(file.path(PACKAGE_DIR,"scripts","04_spatial_permutation.R"),local=FALSE)
source(file.path(PACKAGE_DIR,"scripts","05_integration.R"),local=FALSE)
source(file.path(PACKAGE_DIR,"scripts","06_figures.R"),local=FALSE)

log_msg("COMPLETE","STEP 6 COMPLETE")
