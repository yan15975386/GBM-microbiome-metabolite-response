suppressPackageStartupMessages({
  library(data.table)
})

log_msg <- function(tag, ...) {
  line <- sprintf("%s %-22s %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), tag, paste(...,collapse=" "))
  cat(line,"\n")
  if (exists("LOG_FILE",inherits=TRUE)) cat(line,"\n",file=LOG_FILE,append=TRUE)
}

write_tsv <- function(x,path) {
  dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
  fwrite(as.data.table(x),path,sep="\t",na="NA")
}

bh <- function(p) p.adjust(p,method="BH")

safe_cor <- function(x,y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok)<10 || length(unique(x[ok]))<3 || length(unique(y[ok]))<3) return(NA_real_)
  suppressWarnings(cor(x[ok],y[ok],method="spearman"))
}

pick_file <- function(root,pattern) {
  z <- list.files(root,pattern=pattern,recursive=TRUE,full.names=TRUE,ignore.case=TRUE)
  if (!length(z)) return(NA_character_)
  z[order(nchar(z))][1]
}

z_rows <- function(mat) {
  mu <- rowMeans(mat,na.rm=TRUE)
  ss <- sqrt(pmax(rowMeans(mat^2,na.rm=TRUE)-mu^2,1e-12))
  z <- sweep(mat,1,mu,"-")
  z <- sweep(z,1,ss,"/")
  z[!is.finite(z)] <- 0
  z
}

score_signed <- function(Z,genes,signs) {
  keep <- genes %in% rownames(Z)
  genes <- genes[keep]; signs <- signs[keep]
  if (!length(genes)) return(rep(NA_real_,ncol(Z)))
  colMeans(sweep(Z[genes,,drop=FALSE],1,signs,`*`),na.rm=TRUE)
}

context_score <- function(Z,genes,exclude=character()) {
  g <- intersect(setdiff(genes,exclude),rownames(Z))
  if (!length(g)) return(rep(NA_real_,ncol(Z)))
  colMeans(Z[g,,drop=FALSE],na.rm=TRUE)
}

empirical_one_sided <- function(obs,null,dir) {
  null <- null[is.finite(null)]
  if (!length(null) || !is.finite(obs)) return(NA_real_)
  if (dir>0) (1+sum(null>=obs))/(1+length(null)) else (1+sum(null<=obs))/(1+length(null))
}

find_col <- function(dt, candidates) {
  n <- names(dt); low <- tolower(n)
  for (pat in candidates) {
    hit <- grep(pat,low,perl=TRUE)
    if (length(hit)) return(n[hit[1]])
  }
  NA_character_
}
