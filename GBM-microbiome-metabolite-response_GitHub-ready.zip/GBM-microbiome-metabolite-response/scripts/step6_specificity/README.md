# Step 6 — Cross-modal evidence integration and specificity / negative-control validation

## Purpose
Step 6 does NOT re-select genes, optimize survival cutoffs, or build a new prognostic model.

It answers:
1. Are the fixed IPA / Succinate / TMAO / Propionate host-response programs stronger than expression-matched random programs in TCGA?
2. Are the primary spatial associations stronger than within-slide label-permutation nulls?
3. Do bulk, single-cell and spatial evidence point in the same pre-specified direction?
4. Which axes are sufficiently supported to enter the final manuscript as primary versus secondary mechanisms?

## Fixed primary hypotheses
- IPA: negative with TAM, Inflammatory and MES-like contexts.
- Succinate: positive with TAM, Inflammatory, Proinflammatory-TAM and MES-like contexts.
- TMAO: positive with TAM, Inflammatory and MES-like contexts.
- Propionate: positive with TAM and Inflammatory contexts; secondary axis.

## Specificity tests
### A. TCGA expression-matched random programs
For each fixed program:
- preserve the number of detected genes;
- preserve each gene's activation/inhibition sign;
- match each gene to a random gene from the same mean-expression quantile bin;
- exclude all real program genes and all context-signature genes from the random pool;
- compute 1,000 random programs by default;
- compare the observed signed Spearman correlation to the one-sided null in the pre-specified direction.

This is a specificity test, not another discovery screen.

### B. Spatial within-slide permutation
Using the Step 5 scored-spots cache:
- remove program/context gene overlap exactly as in Step 5;
- calculate the observed within-slide Spearman association;
- permute the context score among spots within each slide;
- collapse slide estimates to patient medians;
- compare the median patient association with 500 permutation null replicates.

No spot-level p value is interpreted as independent evidence.

## Integration philosophy
No arbitrary summed "evidence score" is used.

Axes are classified by rule:
- HIGH-CONFIDENCE CROSS-MODAL: complete gutMGene mechanism + ≥75% pre-specified bulk directional concordance + ≥75% same-spot and neighborhood directional concordance + single-cell support from Step 4/4B + at least one specificity null layer passing FDR<0.05.
- HIGH-CONFIDENCE, MECHANISTICALLY QUALIFIED: same, but robustness analysis shows material dependence on a biologically coherent effector module.
- SECONDARY: reproducible but weaker/less specific or incomplete upstream evidence.

## Expected source roots
- Step 3: `/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/03_bulkRNA`
- Step 4: `/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04_singlecell`
- Step 4B: `/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/04B_singlecell_robustness`
- Step 5: `/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/05_spatial`

## Main outputs
- `06A_source_file_audit.tsv`
- `06B_TCGA_matched_random_observed.tsv`
- `06B_TCGA_matched_random_null_summary.tsv`
- `06B_TCGA_matched_random_empirical_tests.tsv`
- `06C_spatial_permutation_empirical_tests.tsv`
- `06D_cross_modal_direction_concordance.tsv`
- `06E_axis_evidence_matrix.tsv`
- `06F_final_axis_classification.tsv`
- `06G_final_manuscript_claims.tsv`

Figures:
- Figure6A_cross_modal_evidence_map
- Figure6B_TCGA_matched_random_specificity
- Figure6C_spatial_permutation_specificity
- Figure6D_final_axis_summary

## Runtime
The TCGA matched-random analysis is usually moderate.
The spatial permutation section is the slowest part because it performs 500 within-slide permutations for the pre-specified axis-context pairs. It uses the Step 5 target-gene cache and does **not** reload the full Seurat object.

If interrupted after the TCGA null analysis, the already-written tables remain valid; rerunning with the same seed reproduces the same null design.

## v2 FIXED definitions
This version must be run only after Step5 v3 FIXED.
It uses the exact Step3/4/4B program definitions and exact Step3 context signatures.
It also fixes Step3 integration naming (`*_response`, `context_signature`, `host_causal_core`), so TCGA/GSE16011 direction concordance is no longer reported as unavailable.
Outputs are isolated in `06_integration_specificity_v2_fixed`.
