# This file is sourced after 02_run_step3_bulkRNA.R and can also be run separately.
if (!exists("ROOT_OUT")) {
  script_file <- sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE))
  SCRIPT_DIR <- dirname(normalizePath(script_file))
  source(file.path(SCRIPT_DIR,"01_helpers.R"))
  source(file.path(SCRIPT_DIR,"00_config.R"))
}
td <- file.path(ROOT_OUT,"tables"); fd <- file.path(ROOT_OUT,"figures")

# Figure 3A: program-gene signed map
defs <- fread(file.path(td,"03A_metabolite_response_programs.tsv"))
defs[, evidence_label := ifelse(score_set=="host_causal_core","host causal core","expanded only")]
pA <- ggplot(defs,aes(x=program,y=host_gene,fill=factor(sign))) +
  geom_tile(color="white") +
  facet_wrap(~evidence_label,scales="free_y") +
  scale_fill_manual(values=c(`-1`="#4472C4",`1`="#C55A11"),labels=c(`-1`="inhibition",`1`="activation"),name="Curated direction") +
  theme_bw(base_size=10) + theme(axis.text.x=element_text(angle=35,hjust=1),panel.grid=element_blank()) +
  labs(x=NULL,y=NULL,title="Metabolite-linked host-response programs")
ggsave(file.path(fd,"Figure3A_program_gene_map.pdf"),pA,width=9,height=10)
ggsave(file.path(fd,"Figure3A_program_gene_map.png"),pA,width=9,height=10,dpi=300)

plot_heat <- function(dat, cohort_name, title, filebase) {
  # Avoid data.table non-standard-evaluation ambiguity between the column
  # named `cohort` and the function argument. `..cohort` is not valid in i
  # in all data.table versions and caused: object '..cohort' not found.
  d <- dat[cohort == cohort_name & score_version == "host_causal_core"]
  p <- ggplot(d,aes(x=context_signature,y=program,fill=rho)) +
    geom_tile(color="white") +
    geom_text(aes(label=ifelse(is.finite(FDR) & FDR<0.05,"*","")),size=5) +
    scale_fill_gradient2(low="#2F5597",mid="white",high="#C00000",midpoint=0,limits=c(-1,1),na.value="grey90") +
    theme_bw(base_size=10) + theme(axis.text.x=element_text(angle=45,hjust=1),panel.grid=element_blank()) +
    labs(x=NULL,y=NULL,fill="Spearman rho",title=title,subtitle="* BH-FDR < 0.05")
  ggsave(file.path(fd,paste0(filebase,".pdf")),p,width=10,height=4.5)
  ggsave(file.path(fd,paste0(filebase,".png")),p,width=10,height=4.5,dpi=300)
}
full <- fread(file.path(td,"03E_program_context_correlations_full.tsv"))
ov <- fread(file.path(td,"03F_overlap_removed_context_correlations.tsv"))
plot_heat(full,"TCGA","TCGA: full context correlations","Figure3B_TCGA_context_heatmap_full")
plot_heat(ov,"TCGA","TCGA: overlap-removed context correlations","Figure3C_TCGA_context_heatmap_overlap_removed")
plot_heat(ov,"GSE16011","GSE16011: overlap-removed context correlations","Figure3D_GSE16011_context_heatmap_overlap_removed")

# Cox forest, age/sex preferred; fall back to score-only
cox <- fread(file.path(td,"03G_03H_survival_models_score_terms.tsv"))
use <- cox[model=="age_sex" & score_version=="host_causal_core"]
if (!nrow(use)) use <- cox[model=="score_only" & score_version=="host_causal_core"]
if (nrow(use)) {
  use[, label:=paste(cohort,program,sep=" | ")]
  use[, label:=factor(label,levels=rev(label))]
  pE <- ggplot(use,aes(x=HR,y=label,xmin=lower95,xmax=upper95)) +
    geom_vline(xintercept=1,linetype=2) + geom_errorbarh(height=0.15) + geom_point(size=2) +
    scale_x_log10() + theme_bw(base_size=10) +
    labs(x="Hazard ratio per 1 SD score",y=NULL,title="Continuous-score overall-survival associations")
  ggsave(file.path(fd,"Figure3E_Cox_forest.pdf"),pE,width=8,height=5)
  ggsave(file.path(fd,"Figure3E_Cox_forest.png"),pE,width=8,height=5,dpi=300)
}

rep <- fread(file.path(td,"03I_cross_cohort_context_replication.tsv"))
rep <- rep[score_version=="host_causal_core" & is.finite(TCGA_rho) & is.finite(GSE16011_rho)]
if (nrow(rep)) {
  pF <- ggplot(rep,aes(x=TCGA_rho,y=GSE16011_rho)) +
    geom_hline(yintercept=0,linetype=3)+geom_vline(xintercept=0,linetype=3)+geom_abline(slope=1,intercept=0,linetype=2)+
    geom_point(aes(shape=replication_class),size=2.5) +
    geom_text(aes(label=context_signature),check_overlap=TRUE,vjust=-0.6,size=3) +
    facet_wrap(~program) + coord_equal(xlim=c(-1,1),ylim=c(-1,1)) + theme_bw(base_size=10) +
    labs(x="TCGA Spearman rho",y="GSE16011 Spearman rho",title="Cross-cohort context-association concordance")
  ggsave(file.path(fd,"Figure3F_cross_cohort_concordance.pdf"),pF,width=10,height=8)
  ggsave(file.path(fd,"Figure3F_cross_cohort_concordance.png"),pF,width=10,height=8,dpi=300)
}
