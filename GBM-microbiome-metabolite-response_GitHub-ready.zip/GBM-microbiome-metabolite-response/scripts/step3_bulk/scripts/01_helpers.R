options(stringsAsFactors=FALSE, warn=1)

`%||%` <- function(x, y) if (is.null(x) || length(x)==0L || all(is.na(x))) y else x

required_pkgs <- c("data.table","readxl","survival","ggplot2")
missing_pkgs <- required_pkgs[!vapply(required_pkgs, requireNamespace, logical(1), quietly=TRUE)]
if (length(missing_pkgs)) {
  stop("Missing R packages: ", paste(missing_pkgs, collapse=", "),
       "\nInstall once with: install.packages(c(", paste(sprintf('"%s"', missing_pkgs), collapse=", "), "))")
}
suppressPackageStartupMessages({
  library(data.table)
  library(readxl)
  library(survival)
  library(ggplot2)
})

timestamp <- function() format(Sys.time(), "%Y-%m-%d %H:%M:%S")
log_msg <- function(...) {
  txt <- paste0(..., collapse="")
  cat(timestamp(), "  ", txt, "\n", sep="")
}

clean_symbol <- function(x) {
  x <- trimws(as.character(x))
  x[x %in% c("","NA","N/A","NULL","null")] <- NA_character_
  toupper(x)
}

is_mostly_numeric_ids <- function(x) {
  x <- as.character(x); x <- x[!is.na(x)]
  if (!length(x)) return(FALSE)
  mean(grepl("^[0-9]+$", x)) >= 0.8
}

collapse_gene_rows <- function(mat, genes) {
  genes <- clean_symbol(genes)
  keep <- !is.na(genes) & nzchar(genes)
  mat <- mat[keep,,drop=FALSE]; genes <- genes[keep]
  storage.mode(mat) <- "numeric"
  if (!anyDuplicated(genes)) {
    rownames(mat) <- genes
    return(mat)
  }
  dt <- data.table(gene=genes, mat)
  out <- dt[, lapply(.SD, function(z) mean(as.numeric(z), na.rm=TRUE)), by=gene]
  rn <- out$gene
  out[, gene := NULL]
  m <- as.matrix(out); rownames(m) <- rn
  m
}

extract_regex_id <- function(x, pattern) {
  # regmatches() drops unmatched elements when used directly with regexpr(),
  # which can yield character(0) and then NaN from mean() during orientation QC.
  # Preserve input length explicitly so unmatched values become NA.
  x <- toupper(as.character(x))
  m <- regexpr(pattern, x, perl=TRUE)
  ml <- attr(m, "match.length")
  out <- rep(NA_character_, length(x))
  ok <- !is.na(m) & m > 0L & !is.na(ml) & ml > 0L
  if (any(ok)) out[ok] <- substring(x[ok], m[ok], m[ok] + ml[ok] - 1L)
  out
}

normalize_tcga_id <- function(x) extract_regex_id(x, "TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}")
normalize_gsm_id  <- function(x) extract_regex_id(x, "GSM[0-9]+")

match_fraction <- function(x) {
  if (!length(x)) return(0)
  z <- mean(!is.na(x))
  if (!is.finite(z)) 0 else z
}

maybe_log2 <- function(mat, cohort) {
  q99 <- suppressWarnings(as.numeric(quantile(mat, 0.99, na.rm=TRUE)))
  mx <- suppressWarnings(max(mat, na.rm=TRUE))
  mn <- suppressWarnings(min(mat, na.rm=TRUE))
  do_log <- is.finite(mx) && (q99 > 50 || mx > 1000) && mn >= 0
  audit <- data.table(cohort=cohort, min_before=mn, q99_before=q99, max_before=mx, log2_x_plus_1_applied=do_log)
  if (do_log) mat <- log2(mat + 1)
  list(mat=mat, audit=audit)
}

detect_gene_column <- function(dt) {
  nms <- names(dt); low <- tolower(nms)
  cand <- c("gene","gene_symbol","genesymbol","symbol","hgnc_symbol","gene_name","genename")
  hit <- match(cand, low, nomatch=0L); hit <- hit[hit>0]
  if (length(hit)) return(nms[hit[1]])
  # use first nonnumeric column if it looks gene-like
  for (nm in nms[seq_len(min(5,length(nms)))]) {
    v <- dt[[nm]]
    if (is.character(v) && mean(!is.na(v) & nzchar(v)) > 0.8) return(nm)
  }
  nms[1]
}

extract_matrix_from_object <- function(obj) {
  if (is.matrix(obj)) return(obj)
  if (is.data.frame(obj)) return(as.matrix(obj))
  if (inherits(obj, "data.table")) return(as.matrix(obj))
  if (is.list(obj)) {
    priority <- c("expr","expression","expr_mat","matrix","mat","data")
    for (nm in priority) if (!is.null(obj[[nm]]) && (is.matrix(obj[[nm]]) || is.data.frame(obj[[nm]]))) return(as.matrix(obj[[nm]]))
    idx <- which(vapply(obj, function(z) is.matrix(z) || is.data.frame(z), logical(1)))
    if (length(idx)) return(as.matrix(obj[[idx[1]]]))
  }
  stop("Cannot extract an expression matrix from RDS object; top-level class: ", paste(class(obj), collapse=","))
}

map_entrez_to_symbol <- function(ids, mapping_tsv=NULL) {
  ids <- as.character(ids)
  if (!is.null(mapping_tsv) && file.exists(mapping_tsv)) {
    mp <- fread(mapping_tsv)
    nms <- names(mp); low <- tolower(nms)
    entrez_candidates <- nms[grepl("entrez", low)]
    symbol_candidates <- nms[grepl("symbol|gene.*name|hgnc", low)]
    if (length(entrez_candidates) && length(symbol_candidates)) {
      e <- entrez_candidates[1]; s <- symbol_candidates[1]
      map <- unique(mp[!is.na(get(e)) & !is.na(get(s)), .(entrez=as.character(get(e)), symbol=as.character(get(s)))])
      setkey(map, entrez)
      ans <- map[J(ids), symbol]
      if (mean(!is.na(ans)) >= 0.5) return(ans)
    }
  }
  if (requireNamespace("org.Hs.eg.db", quietly=TRUE) && requireNamespace("AnnotationDbi", quietly=TRUE)) {
    suppressMessages({
      ans <- AnnotationDbi::mapIds(org.Hs.eg.db::org.Hs.eg.db, keys=ids, keytype="ENTREZID", column="SYMBOL", multiVals="first")
    })
    return(unname(ans))
  }
  stop("GSE16011 row identifiers look like Entrez IDs, but no usable feature mapping was found and org.Hs.eg.db is unavailable.")
}

load_tcga_expression <- function(path) {
  stopifnot(file.exists(path))
  log_msg("Reading TCGA expression: ", path)
  dt <- as.data.table(readxl::read_excel(path, .name_repair="minimal"))
  gene_col <- detect_gene_column(dt)
  genes <- dt[[gene_col]]
  x <- dt[, setdiff(names(dt), gene_col), with=FALSE]
  if (!ncol(x)) stop("TCGA Excel contains no expression columns after removing gene column: ", gene_col)

  # Convert expression columns to numeric while preserving original TCGA column names.
  xn <- lapply(x, function(v) suppressWarnings(as.numeric(v)))
  mat <- as.matrix(as.data.frame(xn, check.names=FALSE))
  colnames(mat) <- names(x)

  # Robust orientation audit. The uploaded tcga539_exp_unlog.xlsx is expected to be
  # genes in rows (GeneSymbol) and TCGA samples in columns.
  col_ids <- normalize_tcga_id(colnames(mat))
  row_ids <- normalize_tcga_id(as.character(genes))
  col_tcga <- match_fraction(col_ids)
  row_tcga <- match_fraction(row_ids)
  log_msg("TCGA structure audit: gene_column=", gene_col,
          "; feature_rows=", nrow(mat), "; expression_columns=", ncol(mat),
          "; TCGA_ID_fraction_columns=", sprintf("%.3f", col_tcga),
          "; TCGA_ID_fraction_gene_column=", sprintf("%.3f", row_tcga))

  if (col_tcga < 0.5 && row_tcga > 0.5) {
    stop("TCGA Excel appears to have samples in rows rather than columns. Expected genes in rows and TCGA barcodes in columns.")
  }
  if (col_tcga < 0.5) {
    stop("TCGA Excel orientation/sample-name audit failed: fewer than 50% of expression columns contain TCGA patient barcodes.")
  }

  pids <- col_ids
  keep <- !is.na(pids)
  n_input_samples <- ncol(mat)
  mat <- mat[,keep,drop=FALSE]; pids <- pids[keep]
  n_barcode_samples <- ncol(mat)

  mat <- collapse_gene_rows(mat, genes)
  n_genes_after_collapse <- nrow(mat)

  # Collapse multiple aliquots to patient if present.
  if (anyDuplicated(pids)) {
    dtm <- data.table(patient=pids, t(mat))
    dtm <- dtm[, lapply(.SD, mean, na.rm=TRUE), by=patient]
    pids <- dtm$patient; dtm[, patient:=NULL]
    mat <- t(as.matrix(dtm)); colnames(mat) <- pids
  } else colnames(mat) <- pids

  input_audit <- data.table(
    cohort="TCGA", source_file=path, gene_column=gene_col,
    n_feature_rows_input=length(genes), n_expression_columns_input=n_input_samples,
    tcga_id_fraction_columns=col_tcga, tcga_id_fraction_gene_column=row_tcga,
    n_columns_with_valid_tcga_id=n_barcode_samples,
    n_genes_after_symbol_cleanup=n_genes_after_collapse,
    n_unique_patient_ids_after_collapse=length(unique(pids)),
    orientation="genes_in_rows_samples_in_columns"
  )

  lg <- maybe_log2(mat, "TCGA")
  log_msg("TCGA loaded: genes=", nrow(lg$mat), "; patients=", ncol(lg$mat),
          "; log2(x+1)=", lg$audit$log2_x_plus_1_applied)
  list(expr=lg$mat, transform_audit=lg$audit, gene_column=gene_col, input_audit=input_audit)
}

load_gse_expression <- function(path, mapping_tsv=NULL) {
  stopifnot(file.exists(path))
  log_msg("Reading GSE16011 expression: ", path)
  obj <- readRDS(path)
  mat <- extract_matrix_from_object(obj)
  # orient by GSM IDs
  row_gsm <- match_fraction(normalize_gsm_id(rownames(mat)))
  col_gsm <- match_fraction(normalize_gsm_id(colnames(mat)))
  if (row_gsm > col_gsm) mat <- t(mat)
  sids <- normalize_gsm_id(colnames(mat))
  keep <- !is.na(sids)
  if (!any(keep)) stop("No GSM identifiers detected in GSE16011 expression matrix column names.")
  mat <- mat[,keep,drop=FALSE]; sids <- sids[keep]; colnames(mat) <- sids
  genes <- rownames(mat)
  if (is.null(genes)) stop("GSE16011 expression matrix has no row names.")
  if (is_mostly_numeric_ids(genes)) genes <- map_entrez_to_symbol(genes, mapping_tsv)
  mat <- collapse_gene_rows(mat, genes)
  lg <- maybe_log2(mat, "GSE16011")
  list(expr=lg$mat, transform_audit=lg$audit)
}

pick_col <- function(dt, candidates=NULL, regex=NULL) {
  nms <- names(dt); low <- tolower(nms)
  if (!is.null(candidates)) {
    idx <- match(tolower(candidates), low, nomatch=0L); idx <- idx[idx>0]
    if (length(idx)) return(nms[idx[1]])
  }
  if (!is.null(regex)) {
    idx <- grep(regex, low, perl=TRUE)
    if (length(idx)) return(nms[idx[1]])
  }
  NA_character_
}

parse_event <- function(x) {
  if (is.numeric(x) || is.integer(x)) return(as.integer(as.numeric(x) > 0))
  s <- tolower(trimws(as.character(x)))
  out <- rep(NA_integer_, length(s))
  out[s %in% c("1","dead","deceased","death","died","yes","event","true")] <- 1L
  out[s %in% c("0","alive","living","censored","no","false")] <- 0L
  # strings like "1:DECEASED"
  out[is.na(out) & grepl("^1[: _-]|dead|deceas", s)] <- 1L
  out[is.na(out) & grepl("^0[: _-]|alive|living", s)] <- 0L
  out
}

load_clinical <- function(path, cohort) {
  stopifnot(file.exists(path))
  dt <- if (grepl("\\.xlsx?$", path, ignore.case=TRUE)) as.data.table(readxl::read_excel(path)) else fread(path)
  if (cohort=="TCGA") {
    id_col <- pick_col(dt, c("patient_id","bcr_patient_barcode","submitter_id","case_id","sample","sample_id","id"), "patient|barcode|submitter")
    if (is.na(id_col)) {
      # scan for TCGA-looking column
      for (nm in names(dt)) if (mean(!is.na(normalize_tcga_id(dt[[nm]]))) > 0.5) { id_col <- nm; break }
    }
    if (is.na(id_col)) stop(cohort, ": could not detect a TCGA patient ID column in clinical file.")
    ids <- normalize_tcga_id(dt[[id_col]])
  } else {
    id_col <- pick_col(dt, c("geo_accession","gsm","sample_id","sample","id"), "geo_accession|gsm|sample")
    if (is.na(id_col)) {
      for (nm in names(dt)) if (mean(!is.na(normalize_gsm_id(dt[[nm]]))) > 0.5) { id_col <- nm; break }
    }
    if (is.na(id_col)) stop(cohort, ": could not detect a GSM/sample ID column in clinical file.")
    ids <- normalize_gsm_id(dt[[id_col]])
  }
  if (all(is.na(ids))) stop(cohort, ": detected ID column contains no usable normalized identifiers.")
  if (cohort=="TCGA") {
    # Fixed a priori from data_cli_518.xlsx; do not auto-detect alternative OS columns.
    time_col <- TCGA_OS_TIME_COL
    status_col <- TCGA_OS_STATUS_COL
    missing_surv <- setdiff(c(time_col, status_col), names(dt))
    if (length(missing_surv)) stop("TCGA: required survival column(s) missing from clinical file: ", paste(missing_surv, collapse=", "))
  } else {
    time_col <- pick_col(dt,
      c("os_x","os","os_time","overall_survival","overall_survival_time","survival_time","survival","time","days_to_death"),
      "(^|_)os($|_)|overall.*survival|survival.*time|days.*death")
    status_col <- pick_col(dt,
      c("os_status_x","os_status","vital_status","status","event","death","dead"),
      "os.*status|vital.*status|event|death|dead")
    if (is.na(time_col) || is.na(status_col)) stop(cohort, ": survival time/status columns not detected; inspect clinical columns.")
  }
  age_col <- pick_col(dt,c("age","age_at_diagnosis","age_at_initial_pathologic_diagnosis"),"^age$|age.*diagn")
  sex_col <- pick_col(dt,c("sex","gender"),"sex|gender")
  idh_col <- pick_col(dt,NULL,"idh")
  cimp_col <- pick_col(dt,NULL,"cimp")
  subtype_col <- pick_col(dt,c("subtype","transcriptional_subtype","molecular_subtype"),"subtype|transcriptional")
  out <- data.table(sample_id=ids,
                    time=suppressWarnings(as.numeric(dt[[time_col]])),
                    event=parse_event(dt[[status_col]]))
  if (!is.na(age_col)) out[, age:=suppressWarnings(as.numeric(dt[[age_col]]))]
  if (!is.na(sex_col)) out[, sex:=as.factor(dt[[sex_col]])]
  if (!is.na(idh_col)) out[, IDH:=as.factor(dt[[idh_col]])]
  if (!is.na(cimp_col)) out[, CIMP:=as.factor(dt[[cimp_col]])]
  if (!is.na(subtype_col)) out[, subtype:=as.factor(dt[[subtype_col]])]
  out <- out[!is.na(sample_id)]
  if (anyDuplicated(out$sample_id)) out <- out[, .SD[which.max(!is.na(time) & !is.na(event))], by=sample_id]
  audit <- data.table(cohort=cohort,id_column=id_col,time_column=time_col,status_column=status_col,
                      age_column=age_col,sex_column=sex_col,idh_column=idh_col,cimp_column=cimp_col,subtype_column=subtype_col)
  list(clin=out, audit=audit, raw_columns=names(dt))
}

zscore_rows <- function(mat) {
  mu <- rowMeans(mat, na.rm=TRUE)
  sdv <- apply(mat,1,sd,na.rm=TRUE)
  sdv[!is.finite(sdv) | sdv==0] <- NA_real_
  z <- (mat - mu) / sdv
  z[!is.finite(z)] <- NA_real_
  z
}

program_definitions <- function(program_tsv) {
  p <- fread(program_tsv)
  p[, host_gene:=clean_symbol(host_gene)]
  p
}

score_one_program <- function(zmat, defs, version=c("host_causal_core","expanded")) {
  version <- match.arg(version)
  d <- if (version=="host_causal_core") defs[score_set=="host_causal_core"] else defs
  d <- unique(d[,.(host_gene,sign)])
  present <- intersect(d$host_gene, rownames(zmat))
  coverage <- length(present) / nrow(d)
  if (!length(present)) return(list(score=rep(NA_real_,ncol(zmat)), coverage=coverage, n_present=0L, present="", missing=paste(d$host_gene,collapse=";")))
  dd <- d[match(present, host_gene)]
  zz <- zmat[present,,drop=FALSE]
  signed <- zz * dd$sign
  score <- colMeans(signed, na.rm=TRUE)
  score[!is.finite(score)] <- NA_real_
  list(score=score, coverage=coverage, n_present=length(present), present=paste(present,collapse=";"),
       missing=paste(setdiff(d$host_gene,present),collapse=";"))
}

score_programs <- function(expr, program_tsv, cohort, min_coverage=0.6) {
  defs <- program_definitions(program_tsv)
  z <- zscore_rows(expr)
  scores <- data.table(sample_id=colnames(expr))
  audit <- list()
  for (pr in unique(defs$program)) {
    d <- defs[program==pr]
    for (ver in c("host_causal_core","expanded")) {
      s <- score_one_program(z,d,ver)
      nm <- paste(pr,ver,sep="__")
      if (s$coverage < min_coverage) {
        log_msg(cohort, " ", nm, " coverage=", round(s$coverage,3), " < ", min_coverage, "; score set to NA")
        scores[[nm]] <- NA_real_
      } else scores[[nm]] <- s$score
      audit[[length(audit)+1]] <- data.table(cohort=cohort,program=pr,score_version=ver,
          n_defined=if(ver=="host_causal_core") nrow(unique(d[score_set=="host_causal_core",.(host_gene,sign)])) else nrow(unique(d[,.(host_gene,sign)])),
          n_present=s$n_present,coverage=s$coverage,present_genes=s$present,missing_genes=s$missing)
    }
  }
  list(scores=scores,audit=rbindlist(audit,fill=TRUE),zmat=z)
}

score_context <- function(zmat, context_tsv, remove_genes=character(), min_genes=3L) {
  gs <- fread(context_tsv); gs[,gene:=clean_symbol(gene)]
  out <- data.table(sample_id=colnames(zmat))
  aud <- list()
  for (sig in unique(gs$signature)) {
    genes <- setdiff(unique(gs[signature==sig,gene]), clean_symbol(remove_genes))
    present <- intersect(genes,rownames(zmat))
    out[[sig]] <- if(length(present)>=min_genes) colMeans(zmat[present,,drop=FALSE],na.rm=TRUE) else NA_real_
    aud[[length(aud)+1]] <- data.table(signature=sig,n_defined=length(genes),n_present=length(present),
                                      present_genes=paste(present,collapse=";"),removed_overlap=paste(intersect(unique(gs[signature==sig,gene]),clean_symbol(remove_genes)),collapse=";"))
  }
  list(scores=out,audit=rbindlist(aud))
}

spearman_assoc <- function(program_scores, context_scores, cohort, program_tsv, context_tsv, overlap_removed=FALSE) {
  long <- list()
  defs <- fread(program_tsv); defs[,host_gene:=clean_symbol(host_gene)]
  gs <- fread(context_tsv); gs[,gene:=clean_symbol(gene)]
  for (pcol in setdiff(names(program_scores),"sample_id")) {
    parts <- strsplit(pcol,"__",fixed=TRUE)[[1]]; pr <- parts[1]; ver <- parts[2]
    pgenes <- if(ver=="host_causal_core") unique(defs[program==pr & score_set=="host_causal_core",host_gene]) else unique(defs[program==pr,host_gene])
    for (sig in unique(gs$signature)) {
      cgenes <- unique(gs[signature==sig,gene])
      rem <- if(overlap_removed) intersect(cgenes,pgenes) else character()
      # context_scores is the full version; recalc locally from attributes not possible here
      long[[length(long)+1]] <- data.table(program=pr,score_version=ver,context_signature=sig,removed_overlap_genes=paste(rem,collapse=";"))
    }
  }
  rbindlist(long)
}

safe_cor <- function(x,y) {
  ok <- is.finite(x)&is.finite(y)
  if(sum(ok)<20L || sd(x[ok])==0 || sd(y[ok])==0) return(c(rho=NA_real_,p=NA_real_,n=sum(ok)))
  ct <- suppressWarnings(cor.test(x[ok],y[ok],method="spearman",exact=FALSE))
  c(rho=unname(ct$estimate),p=ct$p.value,n=sum(ok))
}

fit_cox_score <- function(dt, score_col, cohort, score_version, program, model_name, covars=character()) {
  use <- c("time","event",score_col,covars)
  x <- copy(dt[, ..use])
  setnames(x, score_col, "score")
  x <- x[is.finite(time) & time>0 & !is.na(event) & is.finite(score)]
  if (nrow(x)<40L || sum(x$event==1,na.rm=TRUE)<20L) return(NULL)
  x[, score_z:=as.numeric(scale(score))]
  vars <- c("score_z",covars)
  vars <- vars[vapply(vars,function(v) v %in% names(x) && sum(!is.na(x[[v]]))>=max(20,0.5*nrow(x)),logical(1))]
  # complete cases for chosen terms
  x <- x[complete.cases(x[,c("time","event",vars),with=FALSE])]
  if (nrow(x)<40L || sum(x$event==1)<20L) return(NULL)
  f <- as.formula(paste("Surv(time,event) ~", paste(vars,collapse=" + ")))
  fit <- try(coxph(f,data=x),silent=TRUE)
  if(inherits(fit,"try-error")) return(NULL)
  sm <- summary(fit)
  co <- as.data.table(sm$coefficients,keep.rownames="term")
  ci <- as.data.table(sm$conf.int,keep.rownames="term2")
  co[,`:=`(HR=ci$`exp(coef)`, lower95=ci$`lower .95`, upper95=ci$`upper .95`)]
  setnames(co,"Pr(>|z|)","p",skip_absent=TRUE)
  if(!"p"%in%names(co)) co[,p:=NA_real_]
  ph <- try(cox.zph(fit),silent=TRUE)
  ph_score <- NA_real_
  if(!inherits(ph,"try-error") && "score_z"%in%rownames(ph$table)) ph_score <- ph$table["score_z","p"]
  co[,`:=`(cohort=cohort,program=program,score_version=score_version,model=model_name,n=nrow(x),events=sum(x$event==1),PH_p_score=ph_score)]
  co[]
}
