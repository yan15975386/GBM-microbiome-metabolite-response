#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
script_file <- sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE))
SCRIPT_DIR <- dirname(normalizePath(script_file))
source(file.path(SCRIPT_DIR,"01_helpers.R"))
source(file.path(SCRIPT_DIR,"00_config.R"))

logfile <- file.path(ROOT_OUT,"logs","Step3_bulkRNA.log")
zz <- file(logfile,open="wt"); sink(zz,type="output",split=TRUE); sink(zz,type="message")
on.exit({sink(type="message");sink(type="output");close(zz)},add=TRUE)
log_msg("STEP3 START")
log_msg("Output: ",ROOT_OUT)

# Save fixed definitions into output
file.copy(PROGRAM_TSV,file.path(ROOT_OUT,"tables","03A_metabolite_response_programs.tsv"),overwrite=TRUE)
file.copy(ANCHOR_TSV,file.path(ROOT_OUT,"tables","03A_program_upstream_anchors.tsv"),overwrite=TRUE)
file.copy(CONTEXT_TSV,file.path(ROOT_OUT,"tables","03A_bulk_context_signatures.tsv"),overwrite=TRUE)

# ---------- 03B load / audit ----------
tcga_e <- load_tcga_expression(TCGA_EXPR_XLSX)
gse_e  <- load_gse_expression(GSE16011_EXPR_RDS,GSE16011_FEATURE_MAP_TSV)
tcga_c <- load_clinical(TCGA_CLIN_XLSX,"TCGA")
gse_c  <- load_clinical(GSE16011_CLIN_TSV,"GSE16011")

fwrite(tcga_e$input_audit,
       file.path(ROOT_OUT,"tables","03B_TCGA_expression_structure_audit.tsv"),sep="\t")
fwrite(rbindlist(list(tcga_e$transform_audit,gse_e$transform_audit),fill=TRUE),
       file.path(ROOT_OUT,"tables","03B_expression_transform_audit.tsv"),sep="\t")
fwrite(rbindlist(list(tcga_c$audit,gse_c$audit),fill=TRUE),
       file.path(ROOT_OUT,"tables","03B_clinical_column_audit.tsv"),sep="\t")
fwrite(data.table(cohort="TCGA",column=tcga_c$raw_columns),file.path(ROOT_OUT,"tables","03B_TCGA_clinical_columns.tsv"),sep="\t")
fwrite(data.table(cohort="GSE16011",column=gse_c$raw_columns),file.path(ROOT_OUT,"tables","03B_GSE16011_clinical_columns.tsv"),sep="\t")

# ---------- 03C/03D scoring ----------
tcga_s <- score_programs(tcga_e$expr,PROGRAM_TSV,"TCGA",MIN_PROGRAM_COVERAGE)
gse_s  <- score_programs(gse_e$expr,PROGRAM_TSV,"GSE16011",MIN_PROGRAM_COVERAGE)
fwrite(rbindlist(list(tcga_s$audit,gse_s$audit),fill=TRUE),file.path(ROOT_OUT,"tables","03B_bulk_input_gene_coverage.tsv"),sep="\t")

tcga_ctx <- score_context(tcga_s$zmat,CONTEXT_TSV,min_genes=MIN_CONTEXT_GENES)
gse_ctx  <- score_context(gse_s$zmat,CONTEXT_TSV,min_genes=MIN_CONTEXT_GENES)
ctx_a <- rbindlist(list(cbind(cohort="TCGA",tcga_ctx$audit),cbind(cohort="GSE16011",gse_ctx$audit)),fill=TRUE)
fwrite(ctx_a,file.path(ROOT_OUT,"tables","03B_context_signature_coverage.tsv"),sep="\t")

tcga_all <- merge(tcga_s$scores,tcga_ctx$scores,by="sample_id",all=TRUE)
gse_all <- merge(gse_s$scores,gse_ctx$scores,by="sample_id",all=TRUE)
fwrite(tcga_all,file.path(ROOT_OUT,"tables","03C_TCGA_program_context_scores.tsv"),sep="\t")
fwrite(gse_all,file.path(ROOT_OUT,"tables","03D_GSE16011_program_context_scores.tsv"),sep="\t")
saveRDS(list(expr=tcga_e$expr,z=tcga_s$zmat,scores=tcga_all,clinical=tcga_c$clin),file.path(ROOT_OUT,"rds","03C_TCGA_step3_objects.rds"))
saveRDS(list(expr=gse_e$expr,z=gse_s$zmat,scores=gse_all,clinical=gse_c$clin),file.path(ROOT_OUT,"rds","03D_GSE16011_step3_objects.rds"))

# ---------- 03E full correlations ----------
program_cols <- setdiff(names(tcga_s$scores),"sample_id")
context_names <- unique(fread(CONTEXT_TSV)$signature)
corr_one <- function(ps,cs,cohort) {
  out <- list()
  for(pc in setdiff(names(ps),"sample_id")) {
    sp <- strsplit(pc,"__",fixed=TRUE)[[1]]
    for(sig in context_names) {
      z <- safe_cor(ps[[pc]],cs[[sig]])
      out[[length(out)+1]] <- data.table(cohort=cohort,program=sp[1],score_version=sp[2],
                                         context_signature=sig,rho=z["rho"],p=z["p"],n=z["n"])
    }
  }
  ans <- rbindlist(out)
  ans[,FDR:=p.adjust(p,method="BH"),by=.(cohort,score_version)]
  ans
}
full_corr <- rbindlist(list(corr_one(tcga_s$scores,tcga_ctx$scores,"TCGA"),
                            corr_one(gse_s$scores,gse_ctx$scores,"GSE16011")))
fwrite(full_corr,file.path(ROOT_OUT,"tables","03E_program_context_correlations_full.tsv"),sep="\t")

# ---------- 03F overlap-removed correlations ----------
defs <- fread(PROGRAM_TSV); defs[,host_gene:=clean_symbol(host_gene)]
ctxdef <- fread(CONTEXT_TSV); ctxdef[,gene:=clean_symbol(gene)]
ov_out <- list()
for(cohort in c("TCGA","GSE16011")) {
  ss <- if(cohort=="TCGA") tcga_s else gse_s
  zmat <- ss$zmat
  for(pc in setdiff(names(ss$scores),"sample_id")) {
    sp <- strsplit(pc,"__",fixed=TRUE)[[1]]; pr<-sp[1]; ver<-sp[2]
    pgenes <- if(ver=="host_causal_core") unique(defs[program==pr & score_set=="host_causal_core",host_gene]) else unique(defs[program==pr,host_gene])
    for(sig in context_names) {
      cgenes0 <- unique(ctxdef[signature==sig,gene])
      rem <- intersect(cgenes0,pgenes)
      cgenes <- setdiff(cgenes0,pgenes)
      present <- intersect(cgenes,rownames(zmat))
      cscore <- if(length(present)>=MIN_CONTEXT_GENES) colMeans(zmat[present,,drop=FALSE],na.rm=TRUE) else rep(NA_real_,ncol(zmat))
      z <- safe_cor(ss$scores[[pc]],cscore)
      ov_out[[length(ov_out)+1]] <- data.table(cohort=cohort,program=pr,score_version=ver,context_signature=sig,
                                               n_original_context_genes=length(cgenes0),n_overlap_removed=length(rem),
                                               overlap_genes=paste(rem,collapse=";"),n_context_genes_after_removal=length(present),
                                               rho=z["rho"],p=z["p"],n=z["n"])
    }
  }
}
ov_corr <- rbindlist(ov_out)
ov_corr[,FDR:=p.adjust(p,method="BH"),by=.(cohort,score_version)]
fwrite(ov_corr,file.path(ROOT_OUT,"tables","03F_overlap_removed_context_correlations.tsv"),sep="\t")

# ---------- 03G/03H survival ----------
surv_out <- list()
run_survival <- function(scores,clin,cohort) {
  dat <- merge(clin,scores,by="sample_id")
  out <- list()
  for(pc in setdiff(names(scores),"sample_id")) {
    sp <- strsplit(pc,"__",fixed=TRUE)[[1]]; pr<-sp[1]; ver<-sp[2]
    m0 <- fit_cox_score(dat,pc,cohort,ver,pr,"score_only",character())
    if(!is.null(m0)) out[[length(out)+1]] <- m0
    cov1 <- intersect(c("age","sex"),names(dat))
    if(length(cov1)) {
      m1 <- fit_cox_score(dat,pc,cohort,ver,pr,"age_sex",cov1)
      if(!is.null(m1)) out[[length(out)+1]] <- m1
    }
    cov2 <- intersect(c("age","sex","IDH","CIMP","subtype"),names(dat))
    if(length(setdiff(cov2,c("age","sex"))) && nrow(dat[complete.cases(dat[,c("time","event",pc,cov2),with=FALSE])])>=MIN_MOLECULAR_MODEL_N) {
      m2 <- fit_cox_score(dat,pc,cohort,ver,pr,"molecular_adjusted",cov2)
      if(!is.null(m2)) out[[length(out)+1]] <- m2
    }
  }
  ans <- rbindlist(out,fill=TRUE)
  if(nrow(ans)) ans[term=="score_z",FDR:=p.adjust(p,method="BH"),by=.(cohort,score_version,model)]
  ans
}
tcga_cox <- run_survival(tcga_s$scores,tcga_c$clin,"TCGA")
gse_cox <- run_survival(gse_s$scores,gse_c$clin,"GSE16011")
coxall <- rbindlist(list(tcga_cox,gse_cox),fill=TRUE)
fwrite(coxall,file.path(ROOT_OUT,"tables","03G_03H_survival_models_all_terms.tsv"),sep="\t")
fwrite(coxall[term=="score_z"],file.path(ROOT_OUT,"tables","03G_03H_survival_models_score_terms.tsv"),sep="\t")

# ---------- 03I cross-cohort replication ----------
tc <- ov_corr[cohort=="TCGA",.(program,score_version,context_signature,TCGA_rho=rho,TCGA_FDR=FDR)]
gs <- ov_corr[cohort=="GSE16011",.(program,score_version,context_signature,GSE16011_rho=rho,GSE16011_FDR=FDR)]
rep_ctx <- merge(tc,gs,by=c("program","score_version","context_signature"),all=TRUE)
rep_ctx[,direction_concordant:=sign(TCGA_rho)==sign(GSE16011_rho)]
rep_ctx[,replication_class:=fifelse(direction_concordant & TCGA_FDR<0.05 & GSE16011_FDR<0.05,"strong",
                            fifelse(direction_concordant & (TCGA_FDR<0.05 | GSE16011_FDR<0.05),"directional_one_cohort",
                            fifelse(direction_concordant,"direction_only","discordant")))]
fwrite(rep_ctx,file.path(ROOT_OUT,"tables","03I_cross_cohort_context_replication.tsv"),sep="\t")

scoreterms <- coxall[term=="score_z"]
tcx <- scoreterms[cohort=="TCGA",.(program,score_version,model,TCGA_HR=HR,TCGA_p=p,TCGA_FDR=FDR)]
gsx <- scoreterms[cohort=="GSE16011",.(program,score_version,model,GSE16011_HR=HR,GSE16011_p=p,GSE16011_FDR=FDR)]
rep_surv <- merge(tcx,gsx,by=c("program","score_version","model"),all=TRUE)
rep_surv[,direction_concordant:=(TCGA_HR>1)==(GSE16011_HR>1)]
fwrite(rep_surv,file.path(ROOT_OUT,"tables","03I_cross_cohort_survival_replication.tsv"),sep="\t")

prog_summary <- rep_ctx[,.(n_contexts=.N,
                           n_direction_concordant=sum(direction_concordant,na.rm=TRUE),
                           n_strong=sum(replication_class=="strong",na.rm=TRUE),
                           n_directional_one_cohort=sum(replication_class=="directional_one_cohort",na.rm=TRUE)),
                       by=.(program,score_version)]
surv_primary <- rep_surv[model=="age_sex",.(program,score_version,survival_HR_direction_concordant=direction_concordant,
                                          TCGA_HR,GSE16011_HR,TCGA_FDR,GSE16011_FDR)]
prog_summary <- merge(prog_summary,surv_primary,by=c("program","score_version"),all.x=TRUE)
fwrite(prog_summary,file.path(ROOT_OUT,"tables","03I_program_level_replication_summary.tsv"),sep="\t")

# ---------- 03J gene-level context ----------
genes <- unique(defs$host_gene)
gene_assoc <- list()
for(cohort in c("TCGA","GSE16011")) {
  zmat <- if(cohort=="TCGA") tcga_s$zmat else gse_s$zmat
  cs <- if(cohort=="TCGA") tcga_ctx$scores else gse_ctx$scores
  for(g in intersect(genes,rownames(zmat))) for(sig in context_names) {
    z<-safe_cor(as.numeric(zmat[g,]),cs[[sig]])
    gene_assoc[[length(gene_assoc)+1]]<-data.table(cohort=cohort,gene=g,context_signature=sig,rho=z["rho"],p=z["p"],n=z["n"])
  }
}
gene_assoc<-rbindlist(gene_assoc)
gene_assoc[,FDR:=p.adjust(p,method="BH"),by=cohort]
fwrite(gene_assoc,file.path(ROOT_OUT,"tables","03J_gene_level_context_correlations.tsv"),sep="\t")

log_msg("STEP3 ANALYSIS COMPLETE. Running figures...")
source(file.path(SCRIPT_DIR,"03_make_figures.R"),local=TRUE)
log_msg("STEP3 COMPLETE")
