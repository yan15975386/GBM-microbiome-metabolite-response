# Step 3 configuration
# All user-specific paths are centralized here.

ROOT_OUT <- "/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/03_bulkRNA"

TCGA_EXPR_XLSX <- "/media/desk16/iy12923/GBM_new/source/TCGA/tcga539_exp_unlog.xlsx"
TCGA_CLIN_XLSX <- "/media/desk16/iy12923/GBM_new/source/TCGA/data_cli_518.xlsx"

# TCGA survival columns are fixed explicitly from the user's clinical matrix.
TCGA_OS_TIME_COL <- "os_x"
TCGA_OS_STATUS_COL <- "os_status_x"

GSE16011_EXPR_RDS <- "/media/desk16/iy12923/GBM_new/gut/02_results/rds/GSE16011_gene_expression_GPL8542_ENTREZ_forced.rds"
GSE16011_CLIN_TSV <- "/media/desk16/iy12923/GBM_new/gut/02_results/tables/GSE16011_Gravendeel_GBM_clinical_survival.tsv"
GSE16011_FEATURE_MAP_TSV <- "/media/desk16/iy12923/GBM_new/gut/02_results/tables/GSE16011_feature_gene_annotation_merged_pipeline.tsv"

SCRIPT_DIR <- normalizePath(dirname(sys.frame(1)$ofile %||% "."), mustWork=FALSE)
PACKAGE_DIR <- normalizePath(file.path(SCRIPT_DIR, ".."), mustWork=FALSE)
CONFIG_DIR <- file.path(PACKAGE_DIR, "config")

PROGRAM_TSV <- file.path(CONFIG_DIR, "03A_metabolite_response_programs.tsv")
ANCHOR_TSV <- file.path(CONFIG_DIR, "03A_program_upstream_anchors.tsv")
CONTEXT_TSV <- file.path(CONFIG_DIR, "03A_bulk_context_signatures.tsv")

MIN_PROGRAM_COVERAGE <- 0.60
MIN_CONTEXT_GENES <- 3L
MIN_SURVIVAL_N <- 40L
MIN_EVENTS <- 20L
MIN_MOLECULAR_MODEL_N <- 60L

dir.create(ROOT_OUT, recursive=TRUE, showWarnings=FALSE)
for (d in c("tables","figures","rds","logs")) dir.create(file.path(ROOT_OUT,d), recursive=TRUE, showWarnings=FALSE)
