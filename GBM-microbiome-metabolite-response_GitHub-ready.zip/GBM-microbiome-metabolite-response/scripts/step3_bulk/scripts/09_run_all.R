#!/usr/bin/env Rscript
script_file <- sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE))
SCRIPT_DIR <- dirname(normalizePath(script_file))
source(file.path(SCRIPT_DIR,"02_run_step3_bulkRNA.R"))
