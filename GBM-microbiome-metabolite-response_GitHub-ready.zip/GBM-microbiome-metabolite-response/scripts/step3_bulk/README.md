# Step 3 — GBM bulk RNA validation

This package uses the newly defined microbiome-first evidence chain and does not reuse the old MMTS/MAPK8-CCL2 screening logic.

## Fixed server inputs

TCGA expression:
`/media/desk16/iy12923/GBM_new/source/TCGA/tcga539_exp_unlog.xlsx`

TCGA clinical:
`/media/desk16/iy12923/GBM_new/source/TCGA/data_cli_518.xlsx`

Fixed TCGA survival columns:
- OS time: `os_x`
- OS status: `os_status_x`

The TCGA loader requires these exact columns and will stop rather than silently selecting another survival field.

GSE16011 expression:
`/media/desk16/iy12923/GBM_new/gut/02_results/rds/GSE16011_gene_expression_GPL8542_ENTREZ_forced.rds`

GSE16011 clinical:
`/media/desk16/iy12923/GBM_new/gut/02_results/tables/GSE16011_Gravendeel_GBM_clinical_survival.tsv`

GSE16011 feature mapping:
`/media/desk16/iy12923/GBM_new/gut/02_results/tables/GSE16011_feature_gene_annotation_merged_pipeline.tsv`


## v3 TCGA loader fix

The uploaded `tcga539_exp_unlog.xlsx` was inspected directly. Its structure is:
- sheet: `Sheet 1`
- dimensions: 12,043 rows × 540 columns including the header row/`GeneSymbol` column
- expression matrix: 12,042 gene rows × 539 TCGA sample columns
- gene column: `GeneSymbol`
- 539/539 expression-column headers contain a valid TCGA patient barcode
- 539 unique TCGA patient IDs in the expression file

The previous loader used `regmatches(regexpr(...))` in a way that drops unmatched gene symbols. Because the gene column contains no TCGA barcodes, this produced a zero-length vector, `mean(logical(0)) = NaN`, and then the error `需要TRUE/FALSE值的地方不可以用缺少值`. v3 preserves vector length explicitly and uses a finite-safe match fraction. The same protection is applied to GSM ID parsing.

A new runtime audit is written to `03B_TCGA_expression_structure_audit.tsv`.

## Four predefined metabolite-linked host response programs

- IPA_response
- Succinate_response
- TMAO_response
- Propionate_response

Two score versions are calculated:
- `host_causal_core`: only genes with curated causal metabolite→host-gene evidence.
- `expanded`: additionally includes correlative/mixed metabolite→gene evidence.

Important: `host_causal_core` does NOT mean the entire microbe→metabolite→gene chain is causal. In particular, TMAO and propionate have weaker upstream microbe→metabolite evidence in the supplied gutMGene records.

Signed score:
mean(z-expression of activation genes) - mean(z-expression of inhibition genes)

This represents tumor transcriptional resemblance to a curated metabolite-linked host response, not measured metabolite concentration or bacterial abundance.

## Main outputs

- 03A_metabolite_response_programs.tsv
- 03B_bulk_input_gene_coverage.tsv
- 03C_TCGA_program_context_scores.tsv
- 03D_GSE16011_program_context_scores.tsv
- 03E_program_context_correlations_full.tsv
- 03F_overlap_removed_context_correlations.tsv
- 03G_03H_survival_models_score_terms.tsv
- 03I_cross_cohort_context_replication.tsv
- 03I_cross_cohort_survival_replication.tsv
- 03I_program_level_replication_summary.tsv
- 03J_gene_level_context_correlations.tsv

Figures are saved as both PDF and PNG.

## Required R packages

data.table, readxl, survival, ggplot2

Optional fallback for Entrez→symbol mapping:
org.Hs.eg.db, AnnotationDbi

The script first tries the existing GSE16011 feature mapping TSV, so Bioconductor packages may not be needed.

## Run after the folder has already been extracted and uploaded

From `/media/desk16/iy12923/GBM_new/gut`:
`cd /media/desk16/iy12923/GBM_new/gut/Step3_GBM_bulkRNA_microbiome_metabolite_pipeline && nohup Rscript scripts/09_run_all.R > step3_console.log 2>&1 & echo $!`

No unzip command is needed.

The internal log is also written to:
`/media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/03_bulkRNA/logs/Step3_bulkRNA.log`


## View logs

Console log:
`tail -n 100 -f /media/desk16/iy12923/GBM_new/gut/Step3_GBM_bulkRNA_microbiome_metabolite_pipeline/step3_console.log`

Internal analysis log:
`tail -n 100 -f /media/desk16/iy12923/GBM_new/gut/gutGBM_microbiome_metabolite_rebuild/03_bulkRNA/logs/Step3_bulkRNA.log`

## v4 figure-only fix
v4 fixes a `data.table` scoping error in `scripts/03_make_figures.R` (`..cohort` not found). If the v3 log already reached `STEP3 ANALYSIS COMPLETE. Running figures...`, the numerical analysis and tables are complete; rerun only `scripts/03_make_figures.R` rather than the whole pipeline.
