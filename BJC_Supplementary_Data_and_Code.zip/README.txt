Additional file 2 — Reproducibility code and derived tables

This archive contains the exact analysis packages and machine-readable result tables used to support the reported analyses.
Public source expression matrices and third-party database files are not redistributed.

Contents:
- Step1_gutMGene: taxonomy harmonization, curated microbe–metabolite/host-gene output tables.
- Step2_gutMDisorder: disease-context evidence tables.
- Step3_bulk: bulk analysis scripts/configuration and derived result tables.
- Step4_singlecell: single-cell localization scripts/configuration and derived summary tables.
- Step4B_robustness: lineage/gene robustness scripts/configuration and derived result tables.
- Step5_spatial: corrected spatial analysis package and derived result tables.
- Step6_specificity: matched-random, spatial permutation, and integration package/results.

The large public source datasets are available from TCGA/GDC or GEO (GSE16011, GSE182109, GSE235672). No new sequencing data were generated.
